import json, sys, pathlib
try:
    import yaml
    from jsonschema import validate
except Exception as e:
    print(f"Missing dependency: {e}")
    sys.exit(2)

if len(sys.argv) != 3:
    print("Usage: validate-registry.py <yaml-file> <schema-file>")
    sys.exit(2)

yaml_file = pathlib.Path(sys.argv[1])
schema_file = pathlib.Path(sys.argv[2])
data = yaml.safe_load(yaml_file.read_text(encoding='utf-8'))
schema = json.loads(schema_file.read_text(encoding='utf-8'))
validate(instance=data, schema=schema)
print(f"Validation succeeded: {yaml_file}")
