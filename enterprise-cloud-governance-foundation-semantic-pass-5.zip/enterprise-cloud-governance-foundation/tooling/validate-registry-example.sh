#!/usr/bin/env bash
set -euo pipefail
python tooling/validate_contracts.py
