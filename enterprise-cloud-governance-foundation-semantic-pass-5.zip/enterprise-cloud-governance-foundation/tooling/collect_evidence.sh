#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-}"
PLATFORM="${2:-}"
TARGET_REF="${3:-}"
EXTRA_REF="${4:-}"

if [[ -z "${MODE}" || -z "${PLATFORM}" ]]; then
  echo "usage: collect_evidence.sh <mode> <platform> [target-ref] [extra-ref]" >&2
  exit 1
fi

mkdir -p evidence
TIMESTAMP="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
AWS_IDENTITY='null'
AZURE_ACCOUNT='null'

if command -v aws >/dev/null 2>&1; then
  AWS_IDENTITY="$(aws sts get-caller-identity --output json 2>/dev/null || echo 'null')"
fi

if command -v az >/dev/null 2>&1; then
  AZURE_ACCOUNT="$(az account show --output json 2>/dev/null || echo 'null')"
fi

cat > "evidence/${MODE}-${PLATFORM}-evidence.json" <<EOF
{
  "mode": "${MODE}",
  "platform": "${PLATFORM}",
  "timestamp_utc": "${TIMESTAMP}",
  "repository": "${GITHUB_REPOSITORY:-}",
  "run_id": "${GITHUB_RUN_ID:-}",
  "run_attempt": "${GITHUB_RUN_ATTEMPT:-}",
  "workflow": "${GITHUB_WORKFLOW:-}",
  "actor": "${GITHUB_ACTOR:-}",
  "sha": "${GITHUB_SHA:-}",
  "ref": "${GITHUB_REF:-}",
  "target_ref": "${TARGET_REF}",
  "extra_ref": "${EXTRA_REF}",
  "aws_region": "${AWS_REGION:-}",
  "azure_location": "${AZURE_LOCATION:-}",
  "aws_caller_identity": ${AWS_IDENTITY},
  "azure_account": ${AZURE_ACCOUNT}
}
EOF
