import pathlib
import re
import sys

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.')
PATTERN = re.compile(r'\[[^\]]*\]\(([^)]+)\)')
IGNORE_DIRS = {'archive'}
errors = []

for path in ROOT.rglob('*.md'):
    if any(part in IGNORE_DIRS for part in path.parts):
        continue
    text = path.read_text(encoding='utf-8')
    for target in PATTERN.findall(text):
        target = target.strip()
        if target.startswith(('http://', 'https://', 'mailto:', '#')):
            continue
        target = target.split('#', 1)[0]
        if not target:
            continue
        resolved = (path.parent / target).resolve()
        if not resolved.exists():
            errors.append(f"{path.relative_to(ROOT)} -> {target}")

if errors:
    print('Broken relative markdown links found:')
    for item in errors:
        print(item)
    sys.exit(1)

print('Relative markdown links validated successfully.')
