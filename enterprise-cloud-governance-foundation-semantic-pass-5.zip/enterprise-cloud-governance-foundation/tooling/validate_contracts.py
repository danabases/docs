#!/usr/bin/env python3
import csv
import json
import sys
from pathlib import Path

try:
    import yaml
    import jsonschema
except Exception as exc:
    print(f"Missing dependency: {exc}", file=sys.stderr)
    sys.exit(2)

ROOT = Path(__file__).resolve().parents[1]

class ValidationError(Exception):
    pass


def load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def validate_schema(data, schema_path: Path, label: str, errors: list[str]):
    schema = load_json(schema_path)
    try:
        jsonschema.validate(instance=data, schema=schema)
    except jsonschema.ValidationError as exc:
        errors.append(f"{label}: schema validation failed at {list(exc.absolute_path)}: {exc.message}")


def validate_control_catalog(errors: list[str]):
    path = ROOT / 'controls/control-catalog.csv'
    rows = list(csv.DictReader(path.read_text(encoding='utf-8').splitlines()))
    schema_path = ROOT / 'schemas/control-catalog.schema.json'
    seen = set()
    for idx, row in enumerate(rows, start=2):
        validate_schema(row, schema_path, f"controls/control-catalog.csv:{idx}", errors)
        cid = row['control_id']
        if cid in seen:
            errors.append(f"controls/control-catalog.csv:{idx}: duplicate control_id {cid}")
        seen.add(cid)
    return {row['control_id']: row for row in rows}


def validate_guardrails(path_rel: str, errors: list[str]):
    path = ROOT / path_rel
    data = load_yaml(path)
    validate_schema(data, ROOT / 'schemas/guardrail-registry.schema.json', path_rel, errors)
    ids = set()
    control_refs = set()
    artifact_refs = set()
    standards_refs = set()
    for idx, item in enumerate(data.get('guardrails', []), start=1):
        gid = item.get('id')
        if gid in ids:
            errors.append(f"{path_rel}: duplicate guardrail id {gid}")
        ids.add(gid)
        control_refs.add(item.get('control_id'))
        impl = item.get('implementation') or {}
        art = impl.get('artifact_path')
        if art:
            artifact_refs.add(art)
            if not (ROOT / art).exists():
                errors.append(f"{path_rel}: artifact_path does not exist: {art}")
        for ref in item.get('references', []) or []:
            standards_refs.add(ref)
            if not (ROOT / ref).exists():
                errors.append(f"{path_rel}: reference path does not exist: {ref}")
    return data, ids, control_refs, artifact_refs, standards_refs


def validate_capability_map(errors: list[str]):
    path_rel = 'controls/platform-capability-map.yaml'
    path = ROOT / path_rel
    data = load_yaml(path)
    validate_schema(data, ROOT / 'schemas/platform-capability-map.schema.json', path_rel, errors)
    ids = set()
    std_refs = set()
    for item in data.get('capabilities', []):
        cid = item.get('capability_id')
        if cid in ids:
            errors.append(f"{path_rel}: duplicate capability_id {cid}")
        ids.add(cid)
        for ref in item.get('standards', []) or []:
            std_refs.add(ref)
            if not (ROOT / ref).exists():
                errors.append(f"{path_rel}: standards path does not exist: {ref}")
    return data, ids, std_refs


def validate_control_mapping(errors: list[str]):
    path_rel = 'controls/mappings/control-mapping.example.yaml'
    path = ROOT / path_rel
    data = load_yaml(path)
    validate_schema(data, ROOT / 'schemas/control-mapping.schema.json', path_rel, errors)
    control_ids = set()
    guardrail_ids = set()
    capability_ids = set()
    artifacts = set()
    for item in data.get('mappings', []):
        control_ids.add(item['control_id'])
        guardrail_ids.update(item.get('guardrail_ids', []))
        capability_ids.update(item.get('capability_ids', []))
        for art in item.get('implementation_artifacts', []):
            artifacts.add(art)
            if not (ROOT / art).exists():
                errors.append(f"{path_rel}: implementation_artifact does not exist: {art}")
    return data, control_ids, guardrail_ids, capability_ids, artifacts


def main():
    errors = []
    controls = validate_control_catalog(errors)
    _, canonical_guardrail_ids, canonical_control_refs, _, canonical_std_refs = validate_guardrails('controls/guardrail-registry.yaml', errors)
    _, example_guardrail_ids, example_control_refs, example_artifacts, example_std_refs = validate_guardrails('controls/mappings/guardrail-registry.example.yaml', errors)
    _, capability_ids, capability_std_refs = validate_capability_map(errors)
    _, mapping_control_ids, mapping_guardrail_ids, mapping_capability_ids, mapping_artifacts = validate_control_mapping(errors)

    all_control_ids = set(controls)
    for source, refs in {
        'controls/guardrail-registry.yaml': canonical_control_refs,
        'controls/mappings/guardrail-registry.example.yaml': example_control_refs,
        'controls/mappings/control-mapping.example.yaml': mapping_control_ids,
    }.items():
        missing = sorted(x for x in refs if x and x not in all_control_ids)
        for x in missing:
            errors.append(f"{source}: references missing control_id {x}")

    missing_guardrails = sorted(x for x in mapping_guardrail_ids if x not in example_guardrail_ids and x not in canonical_guardrail_ids)
    for x in missing_guardrails:
        errors.append(f"controls/mappings/control-mapping.example.yaml: references missing guardrail id {x}")

    missing_capabilities = sorted(x for x in mapping_capability_ids if x not in capability_ids)
    for x in missing_capabilities:
        errors.append(f"controls/mappings/control-mapping.example.yaml: references missing capability_id {x}")

    for std_ref in sorted(canonical_std_refs | example_std_refs | capability_std_refs):
        if not (ROOT / std_ref).exists():
            errors.append(f"cross-file: missing standards reference path {std_ref}")

    # Example mappings should be fully backed by example guardrails.
    for art in sorted(mapping_artifacts):
        if art not in example_artifacts:
            errors.append(f"controls/mappings/control-mapping.example.yaml: artifact {art} is not represented in guardrail example implementation paths")

    if errors:
        print('Contract validation failed:', file=sys.stderr)
        for err in errors:
            print(f"- {err}", file=sys.stderr)
        sys.exit(1)

    print('Contract validation succeeded.')
    print(f"Validated {len(all_control_ids)} controls, {len(canonical_guardrail_ids)} canonical guardrails, {len(example_guardrail_ids)} example guardrails, and {len(capability_ids)} capabilities.")


if __name__ == '__main__':
    main()
