# RACI Accountability Model

## Roles
- Enterprise Architecture / Governance Office
- Architecture Review Board
- Cloud Foundation
- Security Identity
- Security Engineering / SecOps
- Network
- Platform Operations
- Workload Owners
- DBA / Data Platform
- Audit / Risk
- Executive Governance

## Matrix

| Task | A | R | C | I |
|---|---|---|---|---|
| Governance principles approval | Architecture Review Board | Enterprise Architecture | Security, Network, Platform Ops | Workload Owners, DBA/Data Platform |
| Management group / OU model | Cloud Foundation | Cloud Foundation | Security, Network, Platform Ops | Workload Owners, DBA/Data Platform |
| Identity and access standard | Security Identity | Security Identity | Cloud Foundation, Platform Ops | Workload Owners, DBA/Data Platform |
| Policy / SCP / baseline guardrail change | Cloud Foundation | Cloud Foundation | Security, Network, Workload Owners | Audit/Risk, DBA/Data Platform |
| High-impact SCP approval | Executive Governance | Cloud Foundation | Security Engineering, Workload Owners, Audit/Risk | Platform Ops, DBA/Data Platform |
| High-impact SCP outcome validation | Audit / Risk | Audit / Risk | Cloud Foundation, Security Engineering, Workload Owners | Executive Governance |
| Register delegated administrators | Cloud Foundation | Cloud Foundation | Security Engineering | Audit/Risk, Workload Owners |
| Manage log archive account | Security Engineering / SecOps | Security Engineering / SecOps | Cloud Foundation, Audit / Risk | Workload Owners |
| Operate security tooling account | Security Engineering / SecOps | Security Engineering / SecOps | Cloud Foundation, Audit / Risk | Workload Owners |
| Shared network boundary change | Network | Network | Security, Cloud Foundation | Workload Owners, DBA/Data Platform |
| Exception approval | Audit / Risk | Enterprise Architecture / Governance Office | Security, Cloud Foundation, Workload Owners | Executive Governance |
| Workload deployment | Workload Owners | Workload Owners | Platform Ops | Cloud Foundation, DBA/Data Platform |
| Database platform configuration | DBA / Data Platform | DBA / Data Platform | Security, Network | Workload Owners, Cloud Foundation |
| Review emergency access use | Audit / Risk | Security Engineering / SecOps | Cloud Foundation | Executive Governance, Workload Owners |

## Mandatory interpretation rules
1. `I` means reviewable visibility, not silent notification.
2. Tasks affecting service access, policy, network path, encryption, logging, or recovery require early consultation with impacted owners.
3. Top-level governance changes must reference the applicable standard and control ID.
4. Emergency actions require after-action review and evidence capture.
5. Author, approver, deployer, and validator duties should be separated for high-impact controls.
