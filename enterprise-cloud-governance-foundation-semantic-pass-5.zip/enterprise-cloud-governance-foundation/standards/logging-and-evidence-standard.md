# Logging and Evidence Standard

## Purpose
This standard defines the minimum logging, evidence retention, and auditability expectations for governance-plane and workload-affecting controls.

## Requirements
- Privileged activations, policy changes, and exception approvals must produce attributable evidence.
- Organization-wide or tenant-wide audit logging must be centrally retained where supported.
- Logging controls must be protected against unauthorized deletion or suppression.
- Evidence access must be role-based and auditable.
- High-impact governance changes must generate traceable audit events and link back to change records.
- Affected owners must be able to identify the evidence source for a control decision or denial.
