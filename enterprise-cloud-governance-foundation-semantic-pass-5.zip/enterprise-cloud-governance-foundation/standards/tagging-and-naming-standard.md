# Tagging and Naming Standard

## Required Metadata
- environment
- business-owner
- technical-owner
- cost-center
- data-classification
- service-tier
- support-group

## Naming Pattern Example
`<org>-<platform>-<env>-<service>-<region>-<sequence>`
