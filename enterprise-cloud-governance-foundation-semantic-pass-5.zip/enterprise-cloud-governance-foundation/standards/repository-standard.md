# Repository Standard

## Documentation Rules
- every standard must include purpose, scope, owner, review cadence, and linked controls
- every YAML registry must have a validating schema
- diagrams must be stored in editable source form
- markdown is the primary human-readable format
- machine-readable artifacts should be plain text and diff-friendly

## Governance Rules
- CODEOWNERS required
- pull request template required
- major standards changes require at least two reviewers
