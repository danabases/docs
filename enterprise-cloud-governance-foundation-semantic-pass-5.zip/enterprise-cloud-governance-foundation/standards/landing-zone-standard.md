# Landing Zone Standard

## Purpose
This standard defines the minimum governance and operational baseline for newly created or onboarded cloud scopes such as AWS accounts and Azure subscriptions.

## Requirements
- Production and non-production scopes must be separated unless an approved exception exists.
- New scopes must inherit baseline logging, evidence routing, and identity integration before workload onboarding.
- Shared governance planes must be separated from routine workload planes.
- Dedicated security tooling and log archive patterns must be used where the platform supports them.
- Delegated administration must be preferred over routine operation from the highest-risk management plane.

## AWS-specific baseline expectations
- The AWS Organizations management account must be treated as a restricted governance account.
- No application workload may run in the management account.
- Organization-wide CloudTrail and required evidence streams must be centrally retained.
- Security tooling services should operate from dedicated security accounts where supported.
