# Implementation Standard

This standard defines how platform-specific implementation assets should be organized and maintained in this repository.

- Governance, control-definition, implementation, and automation must remain separate layers.
- Shared policies, schemas, and mappings are canonical and must not be copied into multiple implementation roots unless generated.
- Platform automation must use short-lived credentials and environment-based promotion.
- Evidence capture, validation, and review artifacts must be stored in predictable paths.
- Examples are illustrative and must not be treated as the source of truth.
