# Policy as Code Standard

## Purpose
This standard governs how enterprise preventive controls, identity guardrails, and policy metadata are defined, reviewed, validated, and promoted.

## Requirements
- enterprise guardrails must be described declaratively
- policy definitions must be version controlled
- registry metadata must describe ownership, scope, effect, and evidence expectations
- policy changes must pass validation in CI
- pull requests must reference change rationale and impact

## Policy design rules
### Service control policies and equivalent org guardrails
- Use organization-level policies for coarse-grained enterprise guardrails only.
- Use them to restrict high-risk actions such as disabling centralized audit controls, leaving the organization, using disallowed regions, or performing prohibited root-user actions.
- Do not attempt to encode full application authorization logic in organization-level guardrails.

### Permissions boundaries and delegated IAM
- Use permissions boundaries when delegating IAM creation or modification rights.
- Boundary policies must cap the maximum privilege that delegated administrators can assign.
- Delegated IAM patterns must remain reviewable as source artifacts, not opaque generated blobs.

### Authoring and implementation
- Prefer generated-but-readable policy construction methods such as `jsonencode()` or equivalent policy-document helpers.
- Keep policy documents reviewable in source control.
- Separate organization-plane changes from workload-plane changes so approvals and blast radius are explicit.

## Review gates
Every high-impact policy change must include:
- owner
- purpose
- approval record or approval path
- target scope
- rollback or recovery plan
- evidence of validation
