# Identity and Access Standard

## Purpose
This standard defines the enterprise baseline for human, workload, and governance access across multicloud control planes.

## Principles
- federate human access through enterprise identity
- use group-based access and avoid direct user assignment where possible
- eliminate standing broad privilege for routine work
- separate governance, workload, and emergency identities
- use managed identities or OIDC federation instead of static secrets
- require approval and logging for privileged elevation
- maintain reciprocal visibility into privileged control-plane actions

## Requirements
### Effective permission model
- Access design must account for the full evaluation chain, including identity policy, resource policy, organization policy, permissions boundaries, session constraints, and explicit deny precedence.
- Design reviews must distinguish between granted permissions and effective permissions.
- Central teams must not claim sole authority over access outcomes unless they control every relevant policy plane.

### Governance-plane access
- Management-account, tenant-root, and equivalent top-level governance access must be restricted to a small administrative population.
- Routine workload operations must not be performed from top-level governance planes when delegated administration exists.
- Governance-plane access must require MFA for humans and auditable federation or managed identity for automation.

### Delegated administration
- Delegated IAM administration must use permissions boundaries or equivalent maximum-permission controls where supported.
- Governance, workload, and emergency roles must be separated by purpose.
- Workload owners may manage account- or subscription-local roles only inside approved guardrails.

### Visibility and explainability
- Affected owners must have read-only visibility, directly or through governed reporting, into the policies and logs that materially affect them.
- Denials must be explainable in terms of the control plane that enforced them.
