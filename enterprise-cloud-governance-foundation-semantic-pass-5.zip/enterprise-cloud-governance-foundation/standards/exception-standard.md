# Exception Standard

## Required Fields
- exception-id
- requestor
- approver
- control-id
- scope
- rationale
- compensating-controls
- start-date
- end-date
- review-date
- status
