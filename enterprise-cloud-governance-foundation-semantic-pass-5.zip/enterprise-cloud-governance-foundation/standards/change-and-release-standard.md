# Change and Release Standard

## Minimum Change Record
- summary
- affected scope
- reason
- control or standard references
- approvals
- rollout method
- rollback or remediation path
- evidence links
