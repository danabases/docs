# Runner and Network Boundary Model

This document defines where GitHub-hosted runners are appropriate, where self-hosted runners are required, and how runner placement relates to trust boundaries.

## Preferred Default

Use GitHub-hosted runners for:

- linting
- schema and markdown validation
- Terraform preview or apply when no private network access is needed
- CloudFormation preview or deploy
- Azure Bicep validate, what-if, or deploy
- artifact and evidence packaging

## Use Self-Hosted Runners Only for Boundary-Specific Tasks

Use self-hosted runners for:

- Ansible to private targets
- VMware Aria or vSphere API calls not reachable externally
- internal CMDB, ticketing, vault, or service integrations that require private network paths

## CI/CD Runner Pattern

- shared runners for low-risk validation only
- isolated runners for privileged deployment activity
- production deployment runners must be environment-separated
- separate runner groups by risk boundary
- restrict which repositories and environments can use which runner groups

## Runner Hardening Practices

- dedicate runner groups by trust level
- prefer ephemeral runners where practical
- patch and monitor runner hosts
- minimize local credential storage
- use outbound-controlled networking
- avoid co-locating unrelated workloads on privileged runners

## Network Boundary Pattern

- ingress and egress standards documented by zone
- workload-private connectivity patterns documented
- shared network changes require change record and affected-team visibility

## Practical Pattern

### Public-cloud lane

GitHub-hosted runner  
→ OIDC or federated login  
→ preview or deploy  
→ upload evidence

### Internal lane

Self-hosted runner  
→ internal auth or vault retrieval  
→ Ansible or Aria stage  
→ upload evidence
