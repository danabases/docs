# Subscription and Account Vending Model

This document defines the minimum intake, control-plane placement, and onboarding outputs for new AWS accounts, Azure subscriptions, and similarly governed workload boundaries.

## Required Inputs

- business owner
- technical owner
- workload classification
- environment
- connectivity zone
- logging destination
- identity model
- required guardrail profile

## Required Outputs

- standardized naming
- baseline tags
- baseline logging
- baseline policy attachments
- delegated role assignments
- evidence of successful onboarding

## AWS Account Class Model

### Management account

Use only for AWS Organizations root administration, payer and billing administration, trusted service enablement, and delegated administrator registration.

Do not use it for application hosting, routine security operations, or day-to-day engineering activity.

### Log archive account

Use for central CloudTrail and related log retention, protected evidence storage, and controlled audit access.

### Security tooling account

Use for findings aggregation, detection engineering, delegated administration for supported security services, and investigation coordination.

### Shared services or platform account

Use for centrally approved services that legitimately serve multiple accounts.

### Workload accounts

Use as the primary ownership boundaries for applications, data platforms, services, and environment separation.

## Control Plane Layers

### Organizations layer

Primary controls:

- OU structure
- SCPs
- delegated administrator relationships
- trusted service access

### IAM layer

Primary controls:

- identity-based policies
- role trust policies
- permissions boundaries
- federation and role assumption

### Resource layer

Primary controls:

- bucket policies
- key policies
- secrets access rules
- service-specific resource policies

### Evidence layer

Primary controls:

- audit logs
- configuration state capture
- security findings
- retention and access patterns

## Design Principles

- use accounts or subscriptions as hard isolation boundaries
- keep a small set of enterprise controls centralized
- keep workload operations with workload owners
- provide independent visibility to affected owners
- separate policy authoring, deployment, and validation
- prefer delegated administration over routine operation from the management account

## Minimum Model

A minimum viable model includes:

- one management or tenant-governance boundary
- one protected evidence or log-retention boundary
- one security tooling boundary
- one or more shared-services or platform boundaries as needed
- separate workload boundaries for production and non-production

## Traceability Expectations

For any high-impact control, the model should answer:

- which boundary owns the control?
- which team authored it?
- which team approved it?
- which boundaries are affected?
- where is the evidence?
- how does an affected owner request an exception?
