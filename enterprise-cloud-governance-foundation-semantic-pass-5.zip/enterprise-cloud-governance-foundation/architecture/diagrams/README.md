# Diagram Source

The repository includes:

- `diagrams/multicloud-enterprise-structure.mmd` - Mermaid source
- `diagrams/multicloud-enterprise-structure.svg` - rendered SVG

Use the Mermaid source as the version-controlled canonical diagram.
Use the SVG for README and documentation embedding.
