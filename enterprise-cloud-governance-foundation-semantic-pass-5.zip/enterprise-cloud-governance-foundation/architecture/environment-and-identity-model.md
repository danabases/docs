# Environment and Identity Model

This document defines the deployment trust-boundary model for environments, identities, approvals, and workload separation across AWS, Azure, and internal execution lanes.

## Environment Pattern

Use a small, consistent set of lifecycle environments:

- sandbox
- dev
- test
- prod
- shared-services

A GitHub Environment is the deployment trust boundary. It owns the approval model, cloud identity, and permitted execution context for that lane.

## Recommended Environment Naming

Use the pattern:

`<platform>-<scope>-<stage>`

Examples:

- `aws-dev-preview`
- `aws-prod-deploy`
- `azure-dev-preview`
- `azure-prod-deploy`
- `shared-postdeploy`
- `vmware-internal`

## Identity Pattern

Use the following identity defaults:

- enterprise SSO for human access
- just-in-time elevation for privileged roles
- managed identity or OIDC federation for automation
- isolated break-glass identities

## Separation Rules

### By platform

Do not reuse the same environment across AWS and Azure.

### By lifecycle stage

Preview and deploy must use separate environments and, where practical, separate cloud identities.

### By risk boundary

Production must never share the same environment as development or test.

### By network boundary

Internal-only tasks should use their own environment and, where needed, self-hosted runners.

## Recommended Approval Model

- preview environments: minimal or no manual approval
- prod deploy environments: required reviewers
- internal VMware or post-provisioning environments: required reviewers and tighter runner restrictions

## Reference Matrix

| Platform | Environment | Purpose | Identity Pattern | Runner Pattern | Approval Expectation |
|---|---|---|---|---|---|
| AWS | `aws-dev-preview` | Non-prod preview / plan | OIDC-assumed role | GitHub-hosted | Optional or lightweight |
| AWS | `aws-prod-deploy` | Production deployment | OIDC-assumed role | GitHub-hosted or isolated deployment runner | Required |
| Azure | `azure-dev-preview` | Non-prod what-if / validation | Entra workload federation | GitHub-hosted | Optional or lightweight |
| Azure | `azure-prod-deploy` | Production deployment | Entra workload federation | GitHub-hosted | Required |
| Shared | `shared-postdeploy` | Common post-provisioning | Inventory or vault-driven | Self-hosted or GitHub-hosted depending reachability | Required for production |
| VMware | `vmware-internal` | Aria / vSphere internal stage | Internal identity or vault-issued auth | Self-hosted internal | Required |

## Design Notes

- Do not reuse one AWS role across preview and deploy.
- Do not reuse one Azure federated identity across dev and prod without a strong justification.
- Do not run internal VMware stages on public runners when private connectivity is required.
