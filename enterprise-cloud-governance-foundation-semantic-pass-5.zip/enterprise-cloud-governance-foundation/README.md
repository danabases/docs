# Enterprise Cloud Governance Foundation

This repository consolidates the uploaded AWS governance, policy-as-code, Terraform, CloudFormation, multicloud GitHub automation, and enterprise architecture packages into a single canonical monorepo.

## Purpose

Use this repository as the authoritative source for:

- enterprise architecture and governance standards
- machine-readable controls, mappings, and schemas
- AWS policy-as-code assets
- AWS Terraform and CloudFormation implementation layers
- multicloud GitHub workflow orchestration
- Azure and VMware extension patterns
- examples, templates, evidence, and validation tooling

## Repository layout

- `docs/` — executive, operating, implementation, and setup guidance
- `architecture/` — reference architecture, environment model, and diagrams
- `standards/` — governance and implementation standards
- `controls/` — catalog, matrices, registry, mappings, and templates
- `platforms/` — provider-specific implementation and automation assets
- `examples/` — sample parameters, tfvars, policies, and onboarding aids
- `tooling/` — validation and evidence scripts
- `archive/legacy/` — preserved source packages after consolidation

## Execution entry points

- CloudFormation baseline: `platforms/aws/cloudformation/templates/stacks/account-iam-baseline.yaml`
- CloudFormation org catalog: `platforms/aws/cloudformation/templates/stacks/org-policy-catalog.yaml`
- Terraform account baseline: `platforms/aws/terraform/environments/account-iam-baseline/`
- Terraform org policies: `platforms/aws/terraform/environments/org-policies/`
- Azure Bicep baseline: `platforms/azure/bicep/main.bicep`
- Shared workflows: `.github/workflows/`

## Validation model

Pull requests should validate:

- internal markdown links
- guardrail registry schema conformance
- Terraform formatting and validation
- CloudFormation linting
- Bicep compilation

## Consolidation notes

- The original `enterprise-multicloud-architecture-governance-framework` was used as the base structure.
- AWS policy JSON artifacts were normalized under `platforms/aws/policies/`.
- Terraform and CloudFormation starter assets were moved under `platforms/aws/terraform/` and `platforms/aws/cloudformation/`.
- GitHub automation workflows from the uploaded automation and multicloud scaffold repos were merged into `.github/workflows/`.
- Repeated implementation guides, references, and OIDC/GitHub setup documents were merged into shared docs in `docs/`.
- The original package contents are preserved under `archive/legacy/` for traceability.

See `CONSOLIDATION-REPORT.md` and `migration-map.csv` for source-to-target mapping.
