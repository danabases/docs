# Azure Federated Credential Example

Recommended pattern:
- app registration per platform or domain
- separate federated credential subject for repo, branch, and environment
- preview and deploy separated
- prod environment protected by approval
