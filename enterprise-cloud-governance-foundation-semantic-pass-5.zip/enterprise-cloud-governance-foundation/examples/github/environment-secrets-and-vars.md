# GitHub Environment Variables and Secrets Example

## Suggested Environments
- dev
- test
- prod

## Suggested Variables
- PLATFORM
- ENVIRONMENT
- GOVERNANCE_BASELINE_VERSION
- EVIDENCE_BUCKET_OR_STORAGE
- CHANGE_RECORD_ID

Prefer no long-lived secrets where OIDC or federation is supported.
