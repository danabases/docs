# Team Onboarding Example

## Team
Data Platform Engineering

## Requested Scope
Azure prod subscription and AWS prod account integration for managed database platform telemetry.

## Required Reviews
- cloud foundation
- security identity
- network
- observability platform
