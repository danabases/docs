# Repository Instructions

Objectives:
1. Reduce duplication.
2. Preserve intent and traceability.
3. Separate governance, control-definition, implementation, and automation layers.
4. Prefer canonical shared artifacts over copied platform-specific duplicates.
5. Do not invent policy semantics. Flag uncertainty explicitly.
6. Preserve backward compatibility where practical and document breaking changes.
7. Favor machine-readable control definitions and schemas where possible.
8. Every structural change must update README and navigation docs.
9. Proposed deletions must be listed in a deprecation report before removal.
10. Keep AWS, Azure, and VMware implementations aligned to the same governance vocabulary.
