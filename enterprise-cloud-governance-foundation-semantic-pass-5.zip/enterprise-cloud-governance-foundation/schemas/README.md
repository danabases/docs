# Schema and contract layer

This directory contains the canonical JSON Schemas for the repository's machine-readable governance artifacts.

## Active schemas
- `control-catalog.schema.json` - row contract for `controls/control-catalog.csv`
- `guardrail-registry.schema.json` - canonical and example guardrail registry contract
- `platform-capability-map.schema.json` - contract for `controls/platform-capability-map.yaml`
- `control-mapping.schema.json` - contract for `controls/mappings/control-mapping.example.yaml`

## Validation model
Use `python tooling/validate_contracts.py` to validate:
- per-file schema compliance
- control, guardrail, and capability identifier consistency
- implementation artifact path existence
- standards reference path existence
- alignment between example mappings and example guardrails
