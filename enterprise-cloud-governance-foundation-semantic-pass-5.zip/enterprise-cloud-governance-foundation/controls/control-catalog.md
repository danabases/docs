# Control Catalog

| Control ID | Name | Domain | Platform | Criticality | Status | Description |
|---|---|---|---|---|---|---|
| CTRL-001 | Central Guardrail Transparency | Governance | All | High | Active | All policy, role, or exception changes affecting teams must be reviewable. |
| CTRL-002 | Privileged Elevation Logging | Identity | All | High | Active | Privileged access activations must be attributable and retained as evidence. |
| CTRL-003 | Managed Identity or Federation | Identity | Azure\|AWS | High | Active | Automation identities should avoid static secrets where supported. |
| CTRL-004 | Landing Zone Baseline Logging | Observability | Azure\|AWS | High | Active | New cloud scopes must inherit logging and evidence integration. |
| CTRL-005 | Formal Exception Registry | Governance | All | Medium | Active | All approved deviations must be time-bound and discoverable. |
| CTRL-006 | Shared Network Change Visibility | Network | All | High | Active | Changes affecting network paths must be visible to impacted service owners. |
| CTRL-007 | RACI Publication | Governance | All | Medium | Active | A current accountability matrix must be maintained in version control. |
| CTRL-008 | Schema Validation in CI | Repository | All | Medium | Active | Registry artifacts must be validated automatically. |
| CTRL-009 | Effective Permission Model | Identity | AWS | High | Active | AWS access design must account for IAM, resource policies, SCPs, permissions boundaries, session policies, and explicit deny precedence. |
| CTRL-010 | Restricted Management Account | Governance | AWS | High | Active | The AWS Organizations management account must be restricted and excluded from routine workload operations. |
| CTRL-011 | Dedicated Log Archive | Observability | AWS | High | Active | Organization-wide audit evidence must be centrally retained in a dedicated log archive model. |
| CTRL-012 | Dedicated Security Tooling | Security | AWS | Medium | Active | Centralized security services must run from dedicated security tooling accounts where supported. |
| CTRL-013 | Distributed Workload Ownership | Governance | AWS | High | Active | Workload owners must retain operational control inside approved account boundaries and enterprise guardrails. |
| CTRL-014 | Explainable Guardrails | Governance | AWS | High | Active | High-impact denials and control changes must be explainable to affected owners. |
| CTRL-015 | Permissions Boundaries for Delegated IAM | Identity | AWS | High | Active | Delegated IAM administration must use permissions boundaries. |
| CTRL-016 | Account Separation | Architecture | AWS | High | Active | Production and non-production workloads must be separated by account unless approved by exception. |

## Notes
This catalog is the human-readable baseline. Use `control-catalog.csv` and associated schemas for machine processing.
