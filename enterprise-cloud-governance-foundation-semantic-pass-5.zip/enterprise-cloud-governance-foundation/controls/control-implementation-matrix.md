# Control Implementation Matrix

| Control ID | Azure Implementation Pattern | AWS Implementation Pattern | Evidence Source |
|---|---|---|---|
| CTRL-001 | management group policy visibility, RBAC visibility, change records | OU/SCP visibility, IAM change records, change approvals | PR, pipeline, platform logs |
| CTRL-002 | PIM and activity logs | role assumption and audit logs | identity logs, CloudTrail, activity logs |
| CTRL-003 | managed identity, workload federation | OIDC federation, role assumption | identity config, pipeline evidence |
| CTRL-004 | diagnostic baseline, landing zone assignment | account baseline logging, org trail/config | onboarding evidence |
| CTRL-005 | exception registry entry | exception registry entry | registry, approval record |
| CTRL-006 | network change record and notification | network change record and notification | change record, evidence |
| CTRL-007 | published RACI in repo | published RACI in repo | repository evidence |
| CTRL-008 | schema validation workflow | schema validation workflow | CI results |
| CTRL-009 | n/a | IAM evaluation logic documented in design reviews; SCP, boundary, and session-policy considerations made explicit | design docs, review artifacts |
| CTRL-010 | n/a | restricted Organizations management account access; delegated admin preferred for service operation | access review, change logs |
| CTRL-011 | centralized diagnostic export and retention patterns | centralized CloudTrail and protected log archive account | logging config, retention controls |
| CTRL-012 | centralized security tooling subscriptions or tenants where applicable | dedicated security tooling account and delegated security services | service settings, delegated admin config |
| CTRL-013 | workload-team ownership of approved resource groups/subscriptions inside guardrails | workload-owner authority in approved workload accounts inside guardrails | ownership records, IAM definitions |
| CTRL-014 | policy assignment visibility and activity-log traceability | explainable SCP and IAM denials, notification and escalation path | runbooks, notifications, logs |
| CTRL-015 | n/a | permissions-boundary policies applied to delegated IAM roles and creators | boundary policies, IAM role configs |
| CTRL-016 | prod/non-prod subscription separation unless exception | prod/non-prod account separation unless exception | scope inventory, exception records |
