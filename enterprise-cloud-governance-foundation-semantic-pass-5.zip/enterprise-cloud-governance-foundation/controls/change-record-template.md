# Change Record

- Change ID:
- Date:
- Requestor:
- Reviewer(s):
- Summary:
- Affected Standard(s):
- Affected Control(s):
- Affected Scope:
- Implementation Repository / Pipeline:
- Rollback / Remediation:
- Evidence Links:
- Exception Reference:
