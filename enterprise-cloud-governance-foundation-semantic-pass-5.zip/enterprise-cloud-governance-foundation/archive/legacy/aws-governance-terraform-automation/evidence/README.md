# Evidence Directory

This directory is populated at workflow runtime.

Artifacts are intended to capture:
- who ran the workflow
- which ref and SHA were used
- which AWS principal was assumed
- which Terraform version was executed
- which working directory and varfile were used
- plan/apply outputs relevant to the run

Store or forward these artifacts according to enterprise evidence-retention requirements.
