# AWS OIDC Bootstrap Guide for GitHub Actions

## Purpose

This document shows how to bootstrap AWS trust for GitHub Actions using OIDC.

## High-level steps

1. Create an IAM OIDC identity provider in AWS for `https://token.actions.githubusercontent.com`
2. Create one or more IAM roles trusted by that provider
3. Constrain trust policy conditions to:
   - the expected audience (`sts.amazonaws.com`)
   - the expected GitHub repository
   - the expected branch, tag, or environment subject
4. Attach least-privilege policies to each role

## Trust-policy design

GitHub recommends limiting the `sub` condition to your organization, repository, and optionally branch or environment. AWS also recommends constraining trust for GitHub OIDC roles to a specific set of repositories or branches. References:
- https://docs.github.com/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services
- https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-idp_oidc.html

## Example subject values

Typical `sub` values include patterns such as:
- `repo:ORG/REPO:ref:refs/heads/main`
- `repo:ORG/REPO:ref:refs/tags/v1.0.0`
- `repo:ORG/REPO:environment:org-prod-apply`

Use environment-scoped subjects when you want GitHub Environment protections to become part of the trust model.

## Required workflow permissions

The job must request:
- `id-token: write`
- `contents: read`

Without `id-token: write`, the workflow cannot mint the OIDC token needed by the AWS credentials action.

## Operational note

Prefer separate roles for plan and apply. Plan does not need the same write authority as apply.
