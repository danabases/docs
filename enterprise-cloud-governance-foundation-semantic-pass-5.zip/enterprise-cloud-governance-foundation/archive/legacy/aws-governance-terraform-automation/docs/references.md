# References

## GitHub Actions and OIDC
- GitHub Actions documentation: https://docs.github.com/actions
- Configuring OpenID Connect in Amazon Web Services: https://docs.github.com/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services
- About security hardening with OpenID Connect: https://docs.github.com/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect
- Configure AWS Credentials action: https://github.com/aws-actions/configure-aws-credentials

## AWS IAM and OIDC
- OIDC federation in IAM: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_providers_oidc.html
- Create a role for OIDC federation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-idp_oidc.html
- Create an OIDC identity provider in IAM: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_providers_create_oidc.html
- Assume role with web identity: https://docs.aws.amazon.com/sdkref/latest/guide/access-assume-role-web.html
- IAM Principal element (OIDC federated principal details): https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_principal.html

## Terraform
- Core workflow: https://developer.hashicorp.com/terraform/intro/core-workflow
- Terraform CLI overview: https://developer.hashicorp.com/terraform/cli/commands
- terraform plan: https://developer.hashicorp.com/terraform/cli/commands/plan
- terraform apply: https://developer.hashicorp.com/terraform/cli/commands/apply
- Automate Terraform with GitHub Actions / HCP Terraform tutorial: https://developer.hashicorp.com/terraform/tutorials/automation/github-actions
