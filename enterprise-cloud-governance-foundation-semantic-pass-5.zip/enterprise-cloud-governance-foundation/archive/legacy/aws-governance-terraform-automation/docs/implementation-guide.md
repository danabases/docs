# Implementation Guide

## 1. Deployment model

This starter set uses GitHub Actions as the orchestration layer and Terraform as the control implementation layer.

### Flow
1. Developer opens a pull request or triggers a manual workflow.
2. GitHub Actions runs Terraform `fmt`, `init`, `validate`, and `plan`.
3. Workflow stores the plan file, a human-readable plan text file, and evidence JSON as artifacts.
4. Reviewers inspect the plan and approve the change through standard GitHub processes.
5. Apply workflow runs only after approval and environment protections succeed.
6. Apply workflow captures its own evidence bundle.

## 2. Why OIDC is used

GitHub recommends OpenID Connect (OIDC) to access cloud providers without storing long-lived secrets, and AWS supports using an OIDC identity provider with `AssumeRoleWithWebIdentity` for temporary credentials. References:
- GitHub: https://docs.github.com/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services
- GitHub OIDC overview: https://docs.github.com/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect
- AWS IAM OIDC federation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_providers_oidc.html
- AWS role creation for OIDC federation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-idp_oidc.html

## 3. Why plan and apply are separate

Terraform's core workflow is write, plan, apply. The `terraform plan` command previews changes, while `terraform apply` executes them. References:
- Terraform workflow: https://developer.hashicorp.com/terraform/intro/core-workflow
- Terraform plan: https://developer.hashicorp.com/terraform/cli/commands/plan
- Terraform apply: https://developer.hashicorp.com/terraform/cli/commands/apply

This repository keeps them separate so that:
- plan output can be reviewed before change execution
- protected environments can gate apply
- evidence can be preserved at each phase

## 4. Environment strategy

Use separate GitHub Environments for:
- organization control plane plans
- organization control plane applies
- account IAM baseline plans
- account IAM baseline applies

Example:
- `org-dev-plan`
- `org-dev-apply`
- `org-prod-plan`
- `org-prod-apply`
- `acct-dev-plan`
- `acct-dev-apply`

This allows:
- different AWS roles per environment
- different reviewer sets
- different branch restrictions
- different deployment windows

## 5. Evidence strategy

Each workflow collects:
- `aws sts get-caller-identity`
- workflow run identifiers
- git SHA and ref
- Terraform version
- selected working directory and varfile
- plan/apply summaries

Artifacts should be retained according to enterprise evidence and retention policy.

## 6. Least-privilege guidance

Do not use one broad deployment role for all Terraform runs.

Recommended split:
- **Org policy plan role**: read-only org visibility plus whatever read access Terraform needs to build and refresh plans
- **Org policy apply role**: create/update Organizations policies and attachments only
- **Account IAM plan role**: read IAM/account state for target account baseline module
- **Account IAM apply role**: create/update only the IAM managed policies, roles, and attachments needed by that baseline

## 7. Promotion guidance

Use GitHub protected environments to require:
- named reviewers
- deployment branches/tags restrictions
- optional wait timers
- optional self-review restrictions

## References
- GitHub Actions docs: https://docs.github.com/actions
- AWS configure credentials action: https://github.com/aws-actions/configure-aws-credentials
