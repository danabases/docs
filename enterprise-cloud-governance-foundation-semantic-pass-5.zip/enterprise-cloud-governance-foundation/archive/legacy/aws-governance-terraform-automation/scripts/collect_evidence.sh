#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-}"
WORKDIR="${2:-}"
VARFILE="${3:-}"

if [[ -z "${MODE}" || -z "${WORKDIR}" ]]; then
  echo "usage: collect_evidence.sh <plan|apply> <terraform-working-directory> [varfile]" >&2
  exit 1
fi

mkdir -p evidence

AWS_IDENTITY="$(aws sts get-caller-identity --output json)"
TERRAFORM_VERSION="$(terraform version -json)"
TIMESTAMP="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

cat > "evidence/${MODE}-evidence.json" <<EOF
{
  "mode": "${MODE}",
  "timestamp_utc": "${TIMESTAMP}",
  "repository": "${GITHUB_REPOSITORY:-}",
  "run_id": "${GITHUB_RUN_ID:-}",
  "run_attempt": "${GITHUB_RUN_ATTEMPT:-}",
  "workflow": "${GITHUB_WORKFLOW:-}",
  "actor": "${GITHUB_ACTOR:-}",
  "sha": "${GITHUB_SHA:-}",
  "ref": "${GITHUB_REF:-}",
  "terraform_working_directory": "${WORKDIR}",
  "terraform_varfile": "${VARFILE}",
  "aws_region": "${AWS_REGION:-}",
  "aws_caller_identity": ${AWS_IDENTITY},
  "terraform_version": ${TERRAFORM_VERSION}
}
EOF
