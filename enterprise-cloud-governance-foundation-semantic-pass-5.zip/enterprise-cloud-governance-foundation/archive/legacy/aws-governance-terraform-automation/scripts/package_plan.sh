#!/usr/bin/env bash
set -euo pipefail

WORKDIR="${1:-}"
if [[ -z "${WORKDIR}" ]]; then
  echo "usage: package_plan.sh <terraform-working-directory>" >&2
  exit 1
fi

mkdir -p artifacts/plan
cp "${WORKDIR}/tfplan" "artifacts/plan/tfplan"
cp "${WORKDIR}/tfplan.txt" "artifacts/plan/tfplan.txt"

cat > artifacts/plan/manifest.json <<EOF
{
  "terraform_working_directory": "${WORKDIR}",
  "files": [
    "tfplan",
    "tfplan.txt"
  ]
}
EOF
