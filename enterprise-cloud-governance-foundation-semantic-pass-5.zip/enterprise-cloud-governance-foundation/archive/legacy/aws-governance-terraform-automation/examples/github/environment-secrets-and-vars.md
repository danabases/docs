# GitHub Environment Variables and Protection Guidance

## Recommended repository variables
- `AWS_REGION`
- `TF_VERSION`

## Recommended environment variables
Each GitHub Environment should define:
- `AWS_ROLE_ARN`
- optional `TF_WORKING_DIR`
- optional `TF_VARFILE`

## Recommended environment protections
For apply environments:
- required reviewers
- deployment branch restrictions
- optional wait timer
- prevent self-review where appropriate

## Example environments
- `org-dev-plan`
- `org-dev-apply`
- `org-prod-plan`
- `org-prod-apply`
- `acct-dev-plan`
- `acct-dev-apply`
- `acct-prod-plan`
- `acct-prod-apply`
