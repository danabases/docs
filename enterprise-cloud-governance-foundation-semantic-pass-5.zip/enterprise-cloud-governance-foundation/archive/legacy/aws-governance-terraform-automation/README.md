# AWS Governance Terraform Deployment Automation Starter

This repository is a deployment automation companion for the Terraform governance starter set. It provides:

- GitHub Actions workflows for Terraform validate, plan, and apply
- OIDC-based AWS authentication for short-lived credentials
- Separate organization-plane and account-plane deployment paths
- Manual approval/promotion model through GitHub Environments
- Evidence capture for plans, applies, workflow metadata, and selected AWS identity context
- Scripts for packaging plan artifacts and writing evidence bundles

## Repository goals

This starter set is designed to support:

1. **Safe Terraform automation** against AWS with short-lived credentials
2. **Promotion gates** between plan and apply
3. **Evidence capture** suitable for governance and audit workflows
4. **Clear separation** between:
   - org-level governance controls (for example SCP objects and attachments)
   - account-level IAM controls (for example permissions boundaries)
5. **Future extension** to policy validation, drift checks, and deployment attestations

## Design constraints

- Uses **GitHub Actions OIDC** instead of long-lived AWS keys.
- Assumes **manual approval** is enforced through protected GitHub Environments.
- Treats Terraform plans as review artifacts, not auto-approval signals.
- Separates **plan** and **apply** workflows.
- Captures evidence in machine-readable JSON for downstream archival.

## Repository layout

```text
.github/workflows/
  terraform-validate.yml
  terraform-plan.yml
  terraform-apply.yml
docs/
  implementation-guide.md
  aws-oidc-bootstrap-guide.md
  references.md
scripts/
  package_plan.sh
  collect_evidence.sh
examples/
  github/
    environment-secrets-and-vars.md
    oidc-trust-policy-example.json
  tfvars/
    org-policies.auto.tfvars.example
    account-iam-baseline.auto.tfvars.example
evidence/
  README.md
```

## Required GitHub configuration

### Repository or organization variables
- `AWS_REGION`
- `TF_VERSION`

### Environment variables
Use GitHub Environments such as:
- `org-dev-plan`
- `org-dev-apply`
- `acct-dev-plan`
- `acct-dev-apply`

Each environment should define:
- `AWS_ROLE_ARN`
- optional `TF_WORKING_DIR`
- optional `TF_VARFILE`

### Workflow permissions
Workflows that assume AWS roles through OIDC must request:
- `id-token: write`
- `contents: read`

## Required AWS bootstrap

1. Create an IAM OIDC identity provider for GitHub if not already present.
2. Create IAM roles for GitHub Actions, scoped by repository and branch/environment.
3. Limit trust policy `sub` conditions to specific repositories and refs or environments.
4. Grant each role only the least privilege needed for the specific Terraform root module.

## Operating model

- Run **validate** on pull request and push.
- Run **plan** on pull request, on manual dispatch, or before change approval.
- Review plan artifact and evidence bundle.
- Approve deployment in a protected GitHub Environment.
- Run **apply** using the reviewed branch/commit and the matching environment role.

## Evidence bundle

Each plan/apply workflow writes an evidence bundle containing:
- workflow metadata
- git commit context
- Terraform version
- AWS caller identity
- selected environment metadata
- plan/apply output summary files

This is a starter set. It is not a complete compliance platform.
