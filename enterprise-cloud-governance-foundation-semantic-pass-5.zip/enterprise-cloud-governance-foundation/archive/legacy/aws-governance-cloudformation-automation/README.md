# AWS Governance CloudFormation Deployment Automation Starter

This repository is a deployable CI/CD companion for CloudFormation governance artifacts.

It provides:

- GitHub Actions workflows for validate, changeset preview, and deploy
- OIDC-based AWS authentication for short-lived credentials
- Separate organization-plane and account-plane deployment paths
- Evidence capture for validation, change sets, deployment metadata, and caller identity
- Scripts to package change-set outputs and evidence bundles
- Example parameter files and an example GitHub-to-AWS OIDC trust policy

## Design goals

1. Use **short-lived credentials** through GitHub Actions OIDC.
2. Separate **validate / preview / deploy**.
3. Use **CloudFormation change sets** as the review boundary.
4. Capture machine-readable **evidence** for governance and audit workflows.
5. Keep **organization-plane** controls and **account-plane** controls separated.

## Why this model

AWS provides a GitHub Action for CloudFormation deployment that can create or update a stack and supports change-set based updates. CloudFormation itself also supports change sets as the safe review mechanism before executing updates.

## Layout

```text
.github/workflows/
  cfn-validate.yml
  cfn-changeset.yml
  cfn-deploy.yml
docs/
  implementation-guide.md
  multi-cloud-and-vmware-compatibility.md
  aws-oidc-bootstrap-guide.md
  references.md
scripts/
  package_changeset.sh
  collect_evidence.sh
examples/
  github/
    environment-secrets-and-vars.md
    oidc-trust-policy-example.json
  parameters/
    org-policy-catalog.parameters.example.json
    account-iam-baseline.parameters.example.json
evidence/
  README.md
```

## Operating model

- **Validate** on pull request and push.
- **Preview** creates a change set and uploads artifacts for review.
- **Deploy** runs only after approval and environment protections succeed.
- **Evidence** is captured in JSON for each workflow stage.

## Required GitHub configuration

Repository or organization variables:
- `AWS_REGION`

Environment variables:
- `AWS_ROLE_ARN`

Recommended GitHub Environments:
- `org-dev-preview`
- `org-dev-deploy`
- `org-prod-preview`
- `org-prod-deploy`
- `acct-dev-preview`
- `acct-dev-deploy`

## Important note

This is a CI/CD starter set, not a complete release platform.
