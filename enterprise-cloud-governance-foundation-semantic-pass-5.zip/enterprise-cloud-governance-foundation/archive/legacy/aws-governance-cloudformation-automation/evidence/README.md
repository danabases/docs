# Evidence Directory

This directory is populated at workflow runtime.

Artifacts are intended to capture:
- who ran the workflow
- which ref and SHA were used
- which AWS principal was assumed
- which stack, template, and parameters were used
- validation / change-set / deployment metadata
