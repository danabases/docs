# GitHub Environment Variables and Protection Guidance

## Recommended repository variables
- `AWS_REGION`

## Recommended environment variables
Each GitHub Environment should define:
- `AWS_ROLE_ARN`

## Recommended environment protections
For deploy environments:
- required reviewers
- deployment branch restrictions
- optional wait timer
- prevent self-review where appropriate

## Example environments
- `org-dev-preview`
- `org-dev-deploy`
- `org-prod-preview`
- `org-prod-deploy`
- `acct-dev-preview`
- `acct-dev-deploy`
- `acct-prod-preview`
- `acct-prod-deploy`
