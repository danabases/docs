# References

## AWS CloudFormation
- Change sets overview: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-changesets.html
- Create a change set: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-changesets-create.html
- ValidateTemplate API: https://docs.aws.amazon.com/AWSCloudFormation/latest/APIReference/API_ValidateTemplate.html
- CloudFormation GitHub Action: https://github.com/aws-actions/aws-cloudformation-github-deploy

## GitHub Actions and OIDC
- GitHub Actions docs: https://docs.github.com/actions
- GitHub OIDC with AWS: https://docs.github.com/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services
- About security hardening with OIDC: https://docs.github.com/actions/security-for-github-actions/security-hardening-your-deployments/about-security-hardening-with-openid-connect
- AWS configure credentials action: https://github.com/aws-actions/configure-aws-credentials

## Azure
- Azure Resource Manager: https://learn.microsoft.com/en-us/azure/azure-resource-manager/
- Deploy Bicep with GitHub Actions: https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/deploy-github-actions

## VMware / Aria / Salt / Ansible
- Aria Automation + Ansible Open Source integration: https://techdocs.broadcom.com/us/en/vmware-cis/aria/aria-automation/8-18/assembler-on-prem-using-and-managing-master-map-8-18/maphead-set-up-organization/what-are-integrations/what-is-configuration-management/configure-ansible-open-source-integration.html
- Aria Automation + Ansible Automation Platform integration: https://techdocs.broadcom.com/us/en/vmware-cis/aria/aria-automation/8-18/assembler-on-prem-using-and-managing-master-map-8-18/maphead-set-up-organization/what-are-integrations/what-is-configuration-management/configure-ansible-automation-platform-integration.html
- Aria integrations and APIs: https://techdocs.broadcom.com/us/en/vmware-cis/aria/aria-automation/8-13/aria-automation-api-programming-guide-on-prem-8-13/setting-up-cloud-assembly/integrating-with-other-applications.html
- Salt vCenter proxy: https://docs.saltproject.io/en/3006/ref/proxy/all/salt.proxy.vcenter.html
- Salt ESXi proxy deprecation note: https://docs.saltproject.io/en/3007/ref/proxy/all/salt.proxy.esxi.html
- Tanzu Salt docs PDF: https://techdocs.broadcom.com/content/dam/broadcom/techdocs/us/en/pdf/vmware-tanzu/platform/tanzu-salt/10-1/tnz-salt/tnz-salt.pdf
- Ansible AWS CloudFormation module: https://docs.ansible.com/projects/ansible/latest/collections/amazon/aws/cloudformation_module.html
- Ansible Azure RM deployment module: https://docs.ansible.com/projects/ansible/latest/collections/azure/azcollection/azure_rm_deployment_module.html
