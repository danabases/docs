# AWS OIDC Bootstrap Guide for GitHub Actions

## Purpose

Bootstrap AWS trust for GitHub Actions using OpenID Connect.

## High-level steps

1. Create an IAM OIDC identity provider for `https://token.actions.githubusercontent.com`
2. Create one or more IAM roles trusted by that provider
3. Constrain trust policy conditions to:
   - audience `sts.amazonaws.com`
   - repository
   - branch, tag, or environment subject
4. Attach least-privilege policies to each role

## References
- GitHub OIDC with AWS: https://docs.github.com/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services
- AWS IAM OIDC provider docs: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_providers_create_oidc.html
- Create role for OIDC federation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-idp_oidc.html
