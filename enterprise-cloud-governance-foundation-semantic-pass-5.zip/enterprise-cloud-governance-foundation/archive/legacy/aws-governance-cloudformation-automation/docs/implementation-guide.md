# Implementation Guide

## 1. Deployment model

This starter set uses GitHub Actions as the pipeline orchestrator and CloudFormation as the infrastructure deployment engine.

### Flow
1. A pull request or manual dispatch triggers validation.
2. Preview workflow validates the template and creates a change set.
3. The workflow stores validation output, change-set details, and evidence JSON as artifacts.
4. Reviewers inspect the change set.
5. The deploy workflow runs after approval in a protected GitHub Environment.
6. Deploy workflow creates or updates the stack and captures evidence.

## 2. Why OIDC is used

GitHub recommends OpenID Connect for cloud authentication so workflows can obtain short-lived credentials without storing long-lived secrets. AWS IAM supports OIDC federation and role assumption through `AssumeRoleWithWebIdentity`.

References:
- GitHub OIDC with AWS: https://docs.github.com/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services
- AWS IAM OIDC federation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_providers_oidc.html
- AWS role creation for OIDC federation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-idp_oidc.html

## 3. Why change sets are used

AWS CloudFormation change sets let you preview how a stack update will affect running resources before executing the update.

References:
- Change sets overview: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-changesets.html
- Create a change set: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-changesets-create.html

## 4. Validation strategy

Validation is split into:
- YAML/JSON parsing
- `aws cloudformation validate-template`
- optional future expansion to `cfn-lint` and guardrail-specific checks

Reference:
- ValidateTemplate API: https://docs.aws.amazon.com/AWSCloudFormation/latest/APIReference/API_ValidateTemplate.html

## 5. Least-privilege role guidance

Use separate roles for:
- organization preview
- organization deploy
- account preview
- account deploy

Preview roles should be read-only plus the specific API access needed to create non-executed change sets if that is part of your operating model.
Deploy roles should be restricted to only the stacks and actions required by their deployment scope.

## 6. Evidence strategy

Each workflow collects:
- AWS caller identity
- GitHub workflow metadata
- stack name
- template path
- parameter file path
- change set or deploy metadata

Artifacts should be retained according to enterprise evidence policy.
