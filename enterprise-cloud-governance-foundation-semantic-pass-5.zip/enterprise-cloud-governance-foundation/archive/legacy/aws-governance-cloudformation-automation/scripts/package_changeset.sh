#!/usr/bin/env bash
set -euo pipefail
mkdir -p artifacts/changeset
cp create-change-set.json artifacts/changeset/create-change-set.json 2>/dev/null || true
cp describe-change-set.json artifacts/changeset/describe-change-set.json 2>/dev/null || true

cat > artifacts/changeset/manifest.json <<EOF
{
  "files": [
    "create-change-set.json",
    "describe-change-set.json"
  ]
}
EOF
