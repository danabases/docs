#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-}"
STACK_NAME="${2:-}"
TEMPLATE_FILE="${3:-}"
PARAMETER_FILE="${4:-}"

mkdir -p evidence

AWS_IDENTITY="$(aws sts get-caller-identity --output json)"
TIMESTAMP="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

cat > "evidence/${MODE}-evidence.json" <<EOF
{
  "mode": "${MODE}",
  "timestamp_utc": "${TIMESTAMP}",
  "repository": "${GITHUB_REPOSITORY:-}",
  "run_id": "${GITHUB_RUN_ID:-}",
  "run_attempt": "${GITHUB_RUN_ATTEMPT:-}",
  "workflow": "${GITHUB_WORKFLOW:-}",
  "actor": "${GITHUB_ACTOR:-}",
  "sha": "${GITHUB_SHA:-}",
  "ref": "${GITHUB_REF:-}",
  "stack_name": "${STACK_NAME}",
  "template_file": "${TEMPLATE_FILE}",
  "parameter_file": "${PARAMETER_FILE}",
  "aws_region": "${AWS_REGION:-}",
  "aws_caller_identity": ${AWS_IDENTITY}
}
EOF
