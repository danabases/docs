# Implementation Guidance and Examples

## 1. Purpose

This document translates the governance standard into operational examples that can be used by engineering, security, architecture, and audit teams.

## 2. Example: Central Governance Team

### Typical Permissions
Examples:
- `organizations:CreatePolicy`
- `organizations:UpdatePolicy`
- `organizations:AttachPolicy`
- `organizations:DetachPolicy`
- account baseline management functions

### Why They Have Them
These permissions are needed to define and enforce enterprise-wide guardrails across multiple accounts.

### What They Do Not Have by Default
They do not automatically have:
- permission to read production application secrets
- permission to query business data stores
- permission to operate workload deployment pipelines
- permission to change application IAM roles unless separately delegated

### Real-World Scenario
The governance team attaches an SCP to deny use of unapproved Regions and deny `cloudtrail:StopLogging` in production OUs. They have this permission because region control and logging enforcement are enterprise-level guardrails. They do not receive permission to read an RDS customer database just because they manage SCPs.

### References
- https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_examples.html

## 3. Example: Security Tooling / SecOps

### Typical Permissions
Examples:
- delegated administration for supported security services
- read access to centralized audit logs
- ability to manage detection and aggregation services

### Why They Have Them
These permissions are needed to detect threats, investigate events, and maintain enterprise visibility.

### What They Do Not Have by Default
They do not automatically have:
- authority to redeploy business applications
- authority to read every application secret
- authority to modify runtime resources outside incident procedures

### Real-World Scenario
SecOps identifies an unexpected IAM trust-policy change from CloudTrail and validates whether the new trust path created unauthorized access. SecOps investigates the event. SecOps does not, by default, redeploy the application stack unless an incident response procedure explicitly authorizes that action.

### References
- https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/introduction.html

## 4. Example: Log Archive Administrators

### Typical Permissions
Examples:
- administration of the centralized log bucket and retention controls
- access management for evidence retrieval workflows
- encryption and retention configuration for log storage

### Why They Have Them
These permissions are needed to protect audit evidence and make it available for audit, security, and investigation.

### What They Do Not Have by Default
They do not automatically have:
- routine workload administration privileges
- application resource modification privileges
- broad rights to alter member-account configurations

### Real-World Scenario
A log archive administrator manages S3 bucket controls that retain organization-wide CloudTrail evidence. They can maintain retention and secure access patterns for logs. They are not thereby authorized to change application-side IAM roles in a workload account.

### References
- https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/log-archive.html

## 5. Example: Workload Owners

### Typical Permissions
Examples:
- manage application resources in their account
- manage account-local IAM roles within permissions boundaries
- manage CI/CD and service roles aligned to the workload
- access operational logs, findings, and configuration state for their assets

### Why They Have Them
These permissions are needed to build, deploy, operate, and secure the workload inside approved enterprise boundaries.

### What They Do Not Have
They do not have permission to:
- remove or bypass SCPs
- disable mandatory CloudTrail or other required logging
- alter organization delegated administrator settings
- create unrestricted admin roles if blocked by boundary or SCP

### Real-World Scenario
A data platform owner creates an ETL role that can read one S3 prefix, decrypt one KMS key, and write to one Redshift cluster. The owner can do this because it is workload-scoped access inside the account boundary. The owner cannot detach the account from its OU or disable enterprise logging.

### References
- https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html

## 6. Example: Why Denials Must Be Explainable

### Scenario
An application team attempts to create an IAM role and the request fails.

### Investigation Path
The owner should be able to determine whether the denial came from:
- an SCP,
- a permissions boundary,
- an identity policy gap,
- or a service-specific/resource policy restriction.

### Why This Matters
If the owner cannot determine the actual control plane that caused the denial, governance has become opaque and non-operational.

### References
- https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html

## 7. Implementation Guidance for Repo / Code Use

This standards package can be used as source material for:

- policy-as-code backlogs
- guardrail registries
- automated evidence checks
- control mapping to CI/CD gates
- issue templates and exception workflows

Recommended next-step repo additions:
- `/policies/scp/` for JSON SCP examples
- `/policies/permissions-boundaries/` for boundary JSON
- `/schemas/guardrail-registry.schema.json` for guardrail metadata
- `/controls/evidence-mappings.md` for automated evidence collection design
