# References

These are primary AWS references used throughout the governance standard package.

## AWS Organizations and SCPs
- AWS Organizations User Guide — Service control policies (SCPs): https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- AWS Organizations — SCP examples: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_examples.html
- AWS Organizations — Policies and effective policy evaluation: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_effective.html
- AWS Organizations — Integrating services and delegated administration: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_integrate_services.html

## AWS IAM
- IAM policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- IAM best practices: https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html
- IAM permissions boundaries: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- IAM identity-based and resource-based policies: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html

## Logging, Audit, and Security Architecture
- CloudTrail security best practices: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- AWS Prescriptive Guidance — Security Reference Architecture: https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/introduction.html
- AWS Prescriptive Guidance — Log Archive: https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/log-archive.html

## Account Structure and Separation
- AWS Well-Architected Security Pillar — Account management and separation: https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html

## Optional Supporting Guidance
- IAM Access Analyzer overview: https://docs.aws.amazon.com/IAM/latest/UserGuide/what-is-access-analyzer.html
- IAM Access Analyzer policy generation: https://docs.aws.amazon.com/IAM/latest/UserGuide/access-analyzer-policy-generation.html
- AWS Config developer guide: https://docs.aws.amazon.com/config/latest/developerguide/WhatIsConfig.html
