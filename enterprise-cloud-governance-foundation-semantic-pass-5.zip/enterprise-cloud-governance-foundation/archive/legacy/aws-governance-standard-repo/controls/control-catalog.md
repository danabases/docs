# Control Catalog

This catalog provides stable control IDs for implementation tracking, audit mapping, and future policy-as-code alignment.

| Control ID | Title | Requirement Summary | Primary Owner | Evidence |
|---|---|---|---|---|
| AWS-GOV-001 | Effective Permission Model | Access design must account for IAM, resource policies, SCPs, permissions boundaries, session policies, and explicit deny precedence. | Cloud Foundation | Design docs, IAM review artifacts |
| AWS-GOV-002 | Restricted Management Account | The management account must be restricted and not used for routine workload operations. | Cloud Foundation | Access review, change logs |
| AWS-GOV-003 | Dedicated Log Archive | Organization-wide audit evidence must be centrally retained in a dedicated log archive account. | Security / Platform | CloudTrail config, S3 retention config |
| AWS-GOV-004 | Dedicated Security Tooling | Centralized security services must run from dedicated security tooling accounts where supported. | Security Engineering | Delegated admin config, service settings |
| AWS-GOV-005 | Distributed Workload Ownership | Workload owners must retain operational control inside approved account boundaries. | Workload Owners | IAM role definitions, account ownership records |
| AWS-GOV-006 | Explainable Guardrails | High-impact denials and control changes must be explainable to affected owners. | Cloud Foundation / Security | Notifications, runbooks, logs |
| AWS-GOV-007 | Separation of Duties | Author, approver, deployer, and validator roles must be separated for high-impact controls. | Governance / Audit | Approval records, audit trail |
| AWS-GOV-008 | Permissions Boundaries for Delegated IAM | Delegated IAM administration must use permissions boundaries. | Identity / Platform | Boundary policies, IAM role configs |
| AWS-GOV-009 | Protected Logging | Audit logs must be protected from unauthorized deletion or suppression. | Security / Platform | Bucket policy, retention controls |
| AWS-GOV-010 | Account Separation | Production and non-production must be separated by account unless approved by exception. | Architecture / Platform | Account inventory, exception records |

## References
- IAM policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- IAM permissions boundaries: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- CloudTrail security best practices: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- AWS Well-Architected Security Pillar — Account management and separation: https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html
