# Governance RACI Matrix

| Activity | Cloud Foundation | Security Engineering / SecOps | Workload Owner | Audit / Risk | Executive Governance |
|---|---|---|---|---|---|
| Define OU structure | R/A | C | I | C | I |
| Author SCPs | R | C | C | I | A for major policy classes |
| Approve high-impact SCPs | C | C | C | C | A |
| Deploy high-impact SCPs | R | I | I | I | I |
| Validate high-impact SCP outcome | C | C | C | R/A | I |
| Register delegated administrators | R/A | C | I | I | I |
| Manage log archive account | C | R | I | C | I |
| Operate security tooling account | I | R/A | I | C | I |
| Operate workload resources | I | C | R/A | I | I |
| Request policy exception | I | I | R | C | A depending on threshold |
| Review emergency access use | C | R | I | A | I |

Legend:
- **R** = Responsible
- **A** = Accountable
- **C** = Consulted
- **I** = Informed
