# Account and Control Plane Model

## 1. Objective

This document defines the recommended AWS account and control-plane operating model to support the governance standard.

## 2. Account Classes

### 2.1 Management Account
Purpose:
- AWS Organizations root administration
- payer and billing administration
- trusted service enablement
- delegated administrator registration

Must not be used for:
- application hosting
- routine security operations
- day-to-day engineering activity

### References
- https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_effective.html
- https://docs.aws.amazon.com/organizations/latest/userguide/orgs_integrate_services.html

### 2.2 Log Archive Account
Purpose:
- central storage for CloudTrail and other required logs
- immutable or strongly protected evidence retention
- controlled audit access

Must not be used for:
- routine workload deployment
- broad application operations

### References
- https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/log-archive.html

### 2.3 Security Tooling Account
Purpose:
- security findings aggregation
- detection engineering
- delegated administration for supported security services
- investigation and response coordination

Must not be used for:
- owning business applications by default
- bypassing workload ownership without incident authority

### References
- https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/introduction.html

### 2.4 Shared Services / Platform Account
Purpose:
- centrally shared services that legitimately serve multiple accounts
- network, CI/CD, directory, artifact, or enterprise platform services as approved

### 2.5 Workload Accounts
Purpose:
- application, data platform, service, or environment ownership boundaries
- separate production, non-production, sandbox, or regulated workloads

### References
- https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html

## 3. Control Plane Layers

### 3.1 Organizations Layer
Primary controls:
- OU structure
- SCPs
- delegated administrator relationships
- trusted service access

### 3.2 IAM Layer
Primary controls:
- identity-based policies
- role trust policies
- permissions boundaries
- federation and role assumption

### 3.3 Resource Layer
Primary controls:
- S3 bucket policies
- KMS key policies
- Secrets Manager resource policies
- service-specific access rules

### 3.4 Evidence Layer
Primary controls:
- CloudTrail
- Config
- security findings
- log retention and access patterns

## 4. Design Principles

- Use accounts as hard isolation boundaries.
- Keep a small set of enterprise controls centralized.
- Keep workload operations with workload owners.
- Provide independent visibility to affected owners.
- Separate policy authoring, deployment, and validation.
- Prefer delegated administration over routine operation from the management account.

## 5. Minimum Model

A minimum viable enterprise model includes:

- 1 management account
- 1 log archive account
- 1 security tooling account
- 1 or more shared services/platform accounts as needed
- separate workload accounts for production and non-production

## 6. Traceability Expectations

For any high-impact control, the model should answer:

- Which account owns the control?
- Which team authored it?
- Which team approved it?
- Which accounts are affected?
- Where is the evidence?
- How does an affected owner request an exception?
