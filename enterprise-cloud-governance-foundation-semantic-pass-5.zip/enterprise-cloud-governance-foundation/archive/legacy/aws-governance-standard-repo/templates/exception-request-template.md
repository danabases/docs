# Exception Request Template

## 1. Request Metadata
- Request ID:
- Request Date:
- Requestor:
- Business Owner:
- Technical Owner:
- Environment:
- Account ID(s):
- OU(s):

## 2. Control Being Excepted
- Control ID:
- Control Name:
- Standard Section:
- Policy / Guardrail Name:
- Current Enforcement Mechanism:
  - SCP
  - IAM policy
  - permissions boundary
  - resource-based policy
  - logging control
  - account separation rule
  - other

## 3. Exception Description
Describe the exact exception being requested.

## 4. Business Justification
Explain why the exception is needed and why standard implementation is not currently feasible.

## 5. Scope
- Resources affected:
- Principals affected:
- AWS services affected:
- Regions affected:
- Start date:
- End date / review date:

## 6. Risk Assessment
- Confidentiality impact:
- Integrity impact:
- Availability impact:
- Detection impact:
- Compensating controls:

## 7. Alternatives Considered
List alternatives reviewed and why they were not selected.

## 8. Approval Workflow
- Technical review:
- Security review:
- Architecture review:
- Risk / compliance review:
- Final approver:

## 9. Evidence and Monitoring
Describe how the exception will be logged, monitored, and reviewed.

## 10. Rollback / Expiration Plan
Describe how the exception will be removed or reverted.
