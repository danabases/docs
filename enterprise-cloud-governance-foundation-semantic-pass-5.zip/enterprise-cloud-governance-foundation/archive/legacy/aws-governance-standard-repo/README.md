# AWS Governance Standard Repository

This repository contains an enterprise-ready AWS governance standard written for both policy consumption and implementation use.

## Structure

- `standards/governance-standard.md` — normative standard
- `architecture/account-and-control-plane-model.md` — account and control-plane architecture
- `implementation/implementation-guidance-and-examples.md` — implementation guidance and real-world examples
- `controls/control-catalog.md` — control catalog with IDs, evidence, and implementation notes
- `controls/raci-matrix.md` — governance RACI
- `templates/exception-request-template.md` — exception request template
- `references.md` — source references

## Intended Use

This package is designed to support:
- enterprise standards repositories
- GitHub-based policy documentation
- control-to-code mapping
- exception workflows
- future policy-as-code and detective-control automation

## Authoring Notes

- Requirements use RFC-style keywords: **MUST**, **SHOULD**, **MAY**
- Control IDs are stable and suitable for issue tracking, backlog items, and policy-as-code mappings
- Section structure is designed to support future decomposition into docs sites, control registries, or schema-backed frameworks
