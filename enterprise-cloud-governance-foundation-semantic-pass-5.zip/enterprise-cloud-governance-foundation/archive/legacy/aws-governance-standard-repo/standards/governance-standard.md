# AWS Governance Standard
## Authority, Visibility, Effective Permissions, and Accountable Control

## 1. Purpose and Scope

This standard defines how AWS governance controls are implemented across the enterprise using AWS Organizations, IAM, resource policies, permissions boundaries, centralized logging, delegated administration, and account-level ownership models.

The purpose of this standard is to ensure that:

- enterprise guardrails are enforceable,
- workload ownership remains operationally usable,
- visibility is sufficient for affected owners to understand and verify controls,
- and no team exercises silent or unreviewable authority over enterprise resources.

This standard applies to:

- the AWS Organizations management account,
- delegated administrator accounts,
- security tooling accounts,
- log archive accounts,
- shared services accounts,
- and all workload accounts in all environments.

### References
- AWS Well-Architected Security Pillar — Account management and separation: https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html
- AWS Organizations — Service control policies (SCPs): https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- IAM identity-based and resource-based policies: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html

## 2. Normative Language

The key words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** in this document are to be interpreted as requirement levels for enterprise implementation and auditability.

## 3. Governing Technical Rule: Effective Permission Model

AWS access decisions are not controlled by one policy alone. Effective permission is the result of AWS policy evaluation logic.

By default, requests are implicitly denied. A request is allowed only when an applicable **Allow** exists and no applicable **explicit Deny** exists. The final decision may be affected by:

- identity-based IAM policies,
- resource-based policies,
- service control policies (SCPs),
- permissions boundaries,
- session policies,
- and service-specific controls.

**Explicit Deny overrides Allow**.

Accordingly, governance design **MUST** be based on the full evaluation chain, not on any single role or policy document.

### Requirements

- Central teams **MUST NOT** claim sole authority over effective access unless they control every applicable policy plane.
- Workload owners **MUST** be able to determine which policy plane blocked or allowed a request when investigating failures.
- IAM design documents **MUST** distinguish between granted permissions and effective permissions.

### References
- IAM policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- AWS Organizations — SCPs: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- IAM permissions boundaries: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html

## 4. Governance Principle

The enterprise AWS model **MUST** follow this principle:

**Central guardrails. Distributed ownership. Independent visibility.**

This means:

- a limited set of enterprise-wide controls is managed centrally,
- workload and resource owners retain control of their own approved environments and services,
- and teams affected by central controls have enough visibility to understand what controls apply, what changed, who changed it, and how those changes affect their resources.

No team **MAY** operate with silent, unreviewable power.

## 5. Central Governance Authority

The central governance or cloud foundation function is authorized to administer only enterprise-scoped controls that require consistent application across multiple accounts or OUs.

These controls include:

- AWS Organizations structure,
- SCP design and attachment,
- account baseline standards,
- mandatory organization-level logging,
- approved Region restrictions,
- enterprise preventive guardrails,
- and approved delegated administrator registration processes.

### Requirements

- Central governance **MUST NOT** automatically inherit routine operational control over application resources, database data paths, secrets, or workload pipelines.
- Every SCP **MUST** have:
  - a named owner,
  - a business purpose,
  - impacted OUs/accounts,
  - an exception path,
  - and a review date.
- High-impact SCP changes **MUST** require documented approval and post-change validation.
- The management account **MUST NOT** be used for routine workload operations.

### References
- AWS Organizations — SCPs: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- AWS Organizations — SCP examples: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_examples.html
- AWS Organizations — Policies and effective policy evaluation: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_effective.html

## 6. Management Account Restrictions

The AWS Organizations management account is the highest-risk administrative plane in the organization and **MUST** be treated as a restricted governance account.

### Requirements

- No application workloads **MAY** run in the management account.
- Human access to the management account **MUST** be restricted to a very small set of privileged administrators.
- MFA **MUST** be enforced for human administrative access.
- Daily service operations **MUST NOT** be performed from the management account if AWS delegated administration is available for the service.
- Change control **MUST** be required for management-account activity affecting organization structure, policy, or trusted service access.

### References
- AWS Organizations — Policies and effective policy evaluation: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_effective.html
- AWS Organizations — Integrating services and delegated administration: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_integrate_services.html

## 7. Security Tooling and Log Archive Accounts

Security monitoring, audit evidence retention, and cross-account detection **MUST** be implemented using dedicated security accounts.

### Log Archive Account

The Log Archive account **MUST** receive and retain centralized audit and configuration evidence, including organization-wide CloudTrail and other required logs.

#### Requirements

- Organization-wide CloudTrail **MUST** be enabled and delivered centrally.
- Log retention **MUST** be protected against unauthorized deletion or suppression.
- Evidence access **MUST** be role-based and auditable.
- Log Archive administrators **MUST NOT** be treated as workload operators by default.

### Security Tooling Account

The Security Tooling account **MAY** administer centralized detective controls, findings aggregation, delegated security services, and security analytics.

#### Requirements

- Security tooling roles **MUST** be separated from routine workload operations roles.
- Security incident procedures **MUST** define when temporary intervention in workload accounts is allowed.
- Security service administration **SHOULD** use delegated administrator patterns where supported.

### References
- CloudTrail security best practices: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- AWS Prescriptive Guidance — Security Reference Architecture: https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/introduction.html
- AWS Prescriptive Guidance — Log Archive: https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/log-archive.html

## 8. Workload Owner Authority

Workload owners are the accountable operators for their own AWS accounts, resources, pipelines, runtime identities, and application-aligned data paths within enterprise guardrails.

### Requirements

- Workload owners **MUST** retain operational control of their approved resources.
- Workload owners **MAY** manage account-local IAM roles subject to SCPs, permissions boundaries, and enterprise identity rules.
- Workload owners **MUST NOT** be granted the ability to:
  - detach or override SCPs,
  - disable mandatory logging,
  - bypass permissions boundaries,
  - or modify enterprise delegated administrator relationships.
- Production and non-production workloads **MUST** be separated by account unless an approved exception exists.

### References
- AWS Well-Architected Security Pillar — Account management and separation: https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html
- IAM permissions boundaries: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- AWS Organizations — SCPs: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html

## 9. Visibility and Explainability Requirements

No team **MAY** be subject to enterprise controls that are effectively invisible to them.

At a minimum, affected owners **MUST** have read-only visibility, directly or through governed reporting, into:

- effective SCPs or applicable management policies,
- audit records for account-relevant administrative and policy changes,
- relevant configuration history,
- relevant security findings,
- and the documented purpose, owner, and exception process for each applicable guardrail.

### Requirements

- No enterprise control **MAY** be enforced as a black box.
- High-impact policy changes **MUST** generate traceable audit events.
- Affected owners **MUST** have a documented operational contact and escalation path for each enterprise guardrail.
- Denials **MUST** be explainable in terms of the actual control plane that enforced them.

### References
- CloudTrail security best practices: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- IAM policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- AWS Config developer guide: https://docs.aws.amazon.com/config/latest/developerguide/WhatIsConfig.html

## 10. Separation of Duties

No single role or team **MAY** unilaterally design, approve, deploy, and validate the same high-impact governance control without independent oversight.

### Requirements

- High-impact org controls **MUST** separate:
  - policy author,
  - approver,
  - deployer,
  - and validator.
- Centralized logs **MUST** be retained in an account not solely controlled by the same team whose actions are being audited.
- Emergency access procedures **MUST** be logged and reviewed after use.

### References
- CloudTrail security best practices: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- AWS Organizations — SCPs: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html

## 11. Policy-Specific Implementation Rules

### 11.1 SCP Rules

- SCPs **MUST** be used as coarse-grained governance guardrails.
- SCPs **MUST NOT** be described as granting access.
- SCPs **MUST** be attached and reviewed in a way that aligns with OU/account ownership boundaries.

### 11.2 IAM Identity Policy Rules

- Identity policies **MUST** grant task-specific access only.
- Broad wildcards such as `Action: "*"`, `Resource: "*"`, or blanket administrative grants are prohibited unless formally approved by exception.
- Temporary credentials and role-based access **MUST** be preferred over long-lived credentials.

### 11.3 Permissions Boundary Rules

- Any delegated role allowed to create or modify IAM principals **MUST** be restricted by a permissions boundary.
- Permissions boundaries **MUST** cap maximum privileges assignable by delegated administrators.

### 11.4 Resource Policy Rules

- Resource-based policies **MUST** explicitly scope trusted principals and conditions.
- Resource-based policies **MUST NOT** be used to bypass enterprise guardrails.

### 11.5 Logging Rules

- Organization-wide audit logging **MUST** be enabled.
- Log destinations, retention, and access controls **MUST** be centrally protected.

### 11.6 Account Separation Rules

- Production and development/test **MUST NOT** share the same account except by approved exception.
- Accounts **MUST** be organized around security, compliance, and control needs rather than reporting hierarchy alone.

### References
- AWS Organizations — SCPs: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- IAM best practices: https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html
- IAM permissions boundaries: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- IAM identity-based and resource-based policies: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html
- CloudTrail security best practices: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- AWS Well-Architected Security Pillar — Account management and separation: https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html

## 12. Explicitly Prohibited Conditions

The following conditions are prohibited:

- use of the management account as a daily operations account,
- undocumented SCPs or undocumented org-level policy changes,
- inability of workload owners to determine the source of a denial or control change,
- centralized log storage controlled only by the same team whose actions are being audited,
- delegated IAM administration without permissions boundaries,
- and broad administrative authority without time-bound approval or business justification.

## 13. Trust Standard

Trust in this AWS environment is established through:

- explicit authority boundaries,
- constrained privilege,
- protected evidence,
- transparent control intent,
- and independent review.

No administrator, central team, or workload owner is trusted based solely on title or affiliation. Authority is trusted only to the extent that it is explicitly granted, technically constrained, logged, and reviewable.
