# Multi-Cloud GitHub Pipeline Scaffold

This repository is a starter scaffold for deploying and governing a multi-cloud estate from GitHub.

It is designed for:
- **AWS** deployments using CloudFormation or Terraform
- **Azure** deployments using Bicep
- **Shared approval, promotion, and evidence capture**
- **Optional post-provisioning with Ansible**
- **Optional VMware / Aria extension points** through API or script stages

## Goals

1. Use **GitHub Environments** as the promotion and approval boundary.
2. Use **OIDC-based federation** to AWS and Azure instead of long-lived cloud credentials.
3. Keep **provider-native IaC** intact:
   - CloudFormation / Terraform for AWS
   - Bicep for Azure
4. Standardize the **outer control plane**:
   - validation
   - plan / preview
   - deployment
   - evidence capture
5. Support **post-provisioning** and **on-prem extension** stages without forcing one IaC language across all platforms.

## Repository layout

```text
.github/workflows/
  aws-cloudformation.yml
  aws-terraform.yml
  azure-bicep.yml
  ansible-postdeploy.yml
  deploy-aws-cloudformation.yml
  deploy-aws-terraform.yml
  deploy-azure-bicep.yml
  deploy-multicloud-stack.yml
docs/
  architecture-and-best-practices.md
  github-setup-guide.md
  environment-model.md
  runner-strategy.md
  references.md
scripts/
  collect_evidence.sh
  package_preview_artifacts.sh
examples/
  aws/
    oidc-trust-policy-example.json
  azure/
    federated-credential-notes.md
  ansible/
    inventory.example.ini
    site.yml
  vmware/
    aria-api-stage-placeholder.sh
  parameters/
    aws-cloudformation.parameters.example.json
    aws-terraform.tfvars.example
    azure-bicep.parameters.example.json
```

## Recommended operating model

- Validation runs on pull request.
- Preview or plan runs before deployment.
- Deployment runs only through a protected GitHub Environment.
- Each cloud has its own role or service principal and its own environment.
- Evidence artifacts are uploaded for every preview and deploy run.

## Design principle

Use **one pipeline standard, many provider-native deployment engines**.
