# Environment Model

## Purpose

This document defines the recommended GitHub Environment model for a multi-cloud repository.

## Core rule

A GitHub Environment is the deployment trust boundary.

That means:
- it owns the approval model
- it owns the cloud identity for the job
- it constrains where a deployment may run

## Recommended naming convention

`<platform>-<scope>-<stage>`

Examples:
- `aws-dev-preview`
- `aws-prod-deploy`
- `azure-dev-preview`
- `azure-prod-deploy`
- `shared-postdeploy`
- `vmware-internal`

## Separation rules

### By platform
Do not reuse the same environment across AWS and Azure.

### By lifecycle stage
Preview and deploy must use separate environments.

### By risk boundary
Production must never share the same environment as development or test.

### By network boundary
Internal-only tasks should use their own environment and, where needed, self-hosted runners.

## Recommended approval model

- preview environments: minimal or no manual approval
- prod deploy environments: required reviewers
- vmware/internal environments: required reviewers and self-hosted runner restrictions
