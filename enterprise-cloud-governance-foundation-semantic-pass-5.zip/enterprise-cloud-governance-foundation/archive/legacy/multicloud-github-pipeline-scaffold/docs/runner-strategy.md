# Runner Strategy

## Preferred default

Use GitHub-hosted runners for:
- linting
- validation
- public cloud CLI/API steps
- packaging artifacts
- evidence generation

## Use self-hosted runners only when necessary

Use self-hosted runners when:
- access to private vCenter, Aria, or internal APIs is required
- Ansible targets are not reachable from GitHub-hosted runners
- enterprise network controls require execution inside the boundary

## Best practices

- isolate self-hosted runners into runner groups
- dedicate runners by trust level
- avoid placing unrelated workloads on the same runner host
- prefer ephemeral runners where possible
- monitor and patch runner hosts
- avoid storing long-lived credentials locally when federation or vault retrieval can be used
