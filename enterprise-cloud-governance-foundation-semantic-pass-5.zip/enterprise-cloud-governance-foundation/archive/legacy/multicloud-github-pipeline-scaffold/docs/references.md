# References

## GitHub
- GitHub environments: https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments
- GitHub secrets: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets
- GitHub OIDC to AWS: https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-aws

## AWS
- AWS IAM OIDC role creation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-idp_oidc.html
- AWS CloudFormation GitHub Action: https://github.com/aws-actions/aws-cloudformation-github-deploy

## Azure
- Azure GitHub OIDC auth: https://learn.microsoft.com/en-us/azure/developer/github/connect-from-azure-openid-connect
- Azure Bicep deployment with GitHub Actions: https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/deploy-github-actions
