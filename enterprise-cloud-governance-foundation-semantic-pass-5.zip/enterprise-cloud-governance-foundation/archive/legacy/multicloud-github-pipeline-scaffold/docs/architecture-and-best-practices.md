# Architecture and Best Practices

## 1. Architecture pattern

The recommended enterprise pattern is:

1. **Shared CI/CD control plane**
   - GitHub Actions for orchestration, promotion, approvals, artifacts, and evidence

2. **Provider-native IaC layer**
   - AWS CloudFormation or Terraform for AWS
   - Azure Bicep for Azure

3. **Common post-provisioning layer**
   - Ansible for OS, middleware, agent, and application configuration

4. **Optional private-cloud extension layer**
   - VMware Aria / vSphere / API-driven automation invoked as a stage, not as the universal abstraction

This keeps governance consistent while respecting platform-specific deployment models.

## 2. Why GitHub is the right outer control plane

GitHub Actions supports:
- protected deployment environments
- reusable workflows
- artifacts
- OIDC federation
- scoped secrets and variables

GitHub documents deployment environments and environment protection rules as first-class deployment controls.  
References:
- GitHub environments: https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments
- GitHub secrets guidance: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets

## 3. Why OIDC should be the default

For AWS, GitHub recommends OIDC to AWS rather than storing cloud secrets in GitHub, and AWS IAM supports creating roles for OIDC federation.  
For Azure, Microsoft documents GitHub Actions authentication using OIDC and recommends workload identity federation rather than storing long-lived service principal secrets.

References:
- GitHub OIDC to AWS: https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-aws
- AWS OIDC role creation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-idp_oidc.html
- Azure OIDC from GitHub Actions: https://learn.microsoft.com/en-us/azure/developer/github/connect-from-azure-openid-connect

## 4. Provider-native infrastructure engines

Do not try to force one template language across AWS and Azure.

Recommended:
- **AWS**: CloudFormation for AWS-native governance stacks or Terraform where multi-account IaC modules already exist
- **Azure**: Bicep for Azure-native deployments

Microsoft documents GitHub Actions deployment for Bicep, and AWS provides a GitHub Action for CloudFormation stack deployment.  
References:
- Azure Bicep with GitHub Actions: https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/deploy-github-actions
- AWS CloudFormation GitHub Action: https://github.com/aws-actions/aws-cloudformation-github-deploy

## 5. Common post-provisioning pattern

Use Ansible as the common post-provisioning tool for:
- package installation
- OS hardening
- middleware setup
- agent deployment
- application configuration

That keeps configuration logic separate from infrastructure provisioning and lets the same Ansible roles be reused across cloud VMs and on-prem VMs.

## 6. VMware / private cloud integration pattern

Treat VMware Aria / vSphere / private-cloud automation as a **separate stage** that is invoked from the pipeline through:
- an API call
- a script
- a CLI step
- or a job on a self-hosted runner inside the enterprise network

Do not make VMware-specific automation the mandatory base abstraction for AWS and Azure.

## 7. Separation of duties

Use separate GitHub Environments and separate identities for:
- preview vs deploy
- dev vs test vs prod
- AWS vs Azure
- org-plane vs account / subscription-plane

This keeps approvals, credentials, and blast radius separated.

## 8. Evidence model

Every preview and deployment workflow should capture:
- workflow metadata
- commit SHA and ref
- environment name
- caller identity
- preview / plan output
- deployment output

Artifacts should be retained according to enterprise evidence policy.

## 9. Runner strategy

Use GitHub-hosted runners for public-cloud validation and standard CLI tasks unless private network access is required.  
Use self-hosted runners only when:
- private network access is needed
- on-prem APIs are only reachable internally
- there are controlled enterprise toolchain dependencies

## 10. Recommended enterprise target state

- one shared workflow framework
- reusable cloud-specific workflow modules
- environment-based approvals
- OIDC everywhere possible
- Ansible for post-provisioning
- VMware extension stages only where needed
