# GitHub Setup Guide

## 1. Repository structure

Recommended branches:
- `main` for production-ready code
- optional `develop` or trunk-based model depending on enterprise standard

Recommended top-level folders:
- `.github/workflows`
- `docs`
- `scripts`
- `aws`
- `azure`
- `ansible`
- optional `vmware`

## 2. GitHub Environments

Create separate environments for each deployment lane.

### Example environments
- `aws-dev-preview`
- `aws-dev-deploy`
- `aws-prod-preview`
- `aws-prod-deploy`
- `azure-dev-preview`
- `azure-dev-deploy`
- `azure-prod-preview`
- `azure-prod-deploy`
- `shared-postdeploy`
- `vmware-internal`

Use required reviewers and deployment branch restrictions for deploy environments.

Reference:
- GitHub environments: https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments

## 3. Repository variables

Recommended repository variables:
- `AWS_REGION`
- `TF_VERSION`
- `AZURE_LOCATION`

## 4. Environment variables

Recommended environment-level variables:
- `AWS_ROLE_ARN`
- `AZURE_CLIENT_ID`
- `AZURE_TENANT_ID`
- `AZURE_SUBSCRIPTION_ID`
- optional `TF_WORKING_DIR`
- optional `BICEP_TEMPLATE`
- optional `ANSIBLE_INVENTORY`

Do not store values at repository scope if they differ by environment or security boundary.

## 5. Secrets strategy

Use secrets only where OIDC or federated identity cannot replace them.

GitHub documents using secrets for sensitive values and masking them in logs.  
Reference:
- GitHub secrets: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets

## 6. AWS setup

Create AWS IAM OIDC trust for GitHub and use role assumption for each environment or lane.

Minimum pattern:
- preview role
- deploy role
- separate prod role

References:
- GitHub OIDC to AWS: https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-aws
- AWS OIDC role creation: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_create_for-idp_oidc.html

## 7. Azure setup

Create Microsoft Entra application and federated credentials for GitHub.  
Microsoft documents OIDC-based authentication from GitHub Actions to Azure.

References:
- Azure GitHub OIDC auth: https://learn.microsoft.com/en-us/azure/developer/github/connect-from-azure-openid-connect
- Azure Bicep via GitHub Actions: https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/deploy-github-actions

## 8. Self-hosted runner guidance

Use self-hosted runners only for:
- Ansible to private targets
- VMware / Aria internal API calls
- enterprise-only internal systems

Put self-hosted runners:
- in isolated runner groups
- behind outbound-controlled networking
- with minimal persistent tools
- with patching and monitoring
