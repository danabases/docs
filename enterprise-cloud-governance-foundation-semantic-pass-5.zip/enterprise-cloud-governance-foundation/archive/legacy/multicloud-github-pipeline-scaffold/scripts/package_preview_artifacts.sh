#!/usr/bin/env bash
set -euo pipefail
mkdir -p artifacts/preview
for f in "$@"; do
  if [[ -f "$f" ]]; then
    cp "$f" artifacts/preview/
  fi
done
