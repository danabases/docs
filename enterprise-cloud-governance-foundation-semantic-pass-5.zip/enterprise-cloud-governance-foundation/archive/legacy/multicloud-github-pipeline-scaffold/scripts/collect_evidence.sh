#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-}"
PLATFORM="${2:-}"
TARGET="${3:-}"

mkdir -p evidence
TIMESTAMP="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

cat > "evidence/${PLATFORM}-${MODE}-evidence.json" <<EOF
{
  "mode": "${MODE}",
  "platform": "${PLATFORM}",
  "target": "${TARGET}",
  "timestamp_utc": "${TIMESTAMP}",
  "repository": "${GITHUB_REPOSITORY:-}",
  "run_id": "${GITHUB_RUN_ID:-}",
  "workflow": "${GITHUB_WORKFLOW:-}",
  "actor": "${GITHUB_ACTOR:-}",
  "sha": "${GITHUB_SHA:-}",
  "ref": "${GITHUB_REF:-}",
  "job": "${GITHUB_JOB:-}"
}
EOF
