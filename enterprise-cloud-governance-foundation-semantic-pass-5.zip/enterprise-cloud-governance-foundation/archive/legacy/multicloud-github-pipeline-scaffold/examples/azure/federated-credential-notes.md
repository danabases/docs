# Azure Federated Credential Notes

Create a Microsoft Entra application for GitHub Actions and configure federated credentials per environment or deployment lane.

Recommended split:
- one application or federated credential set for AWS-equivalent dev lane
- one for prod lane
- separate preview and deploy credentials where approvals and blast radius differ

Core values used by `azure/login@v2`:
- `AZURE_CLIENT_ID`
- `AZURE_TENANT_ID`
- `AZURE_SUBSCRIPTION_ID`

References:
- https://learn.microsoft.com/en-us/azure/developer/github/connect-from-azure-openid-connect
- https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/deploy-github-actions
