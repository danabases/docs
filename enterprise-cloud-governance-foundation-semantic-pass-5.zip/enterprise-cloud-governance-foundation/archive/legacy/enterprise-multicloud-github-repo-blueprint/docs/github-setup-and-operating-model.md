# GitHub Setup and Operating Model

## 1. Repository settings

Recommended baseline:
- protect `main`
- require pull requests
- require status checks
- restrict direct pushes
- require review for workflow changes
- enable artifact retention according to enterprise policy

## 2. GitHub Environments

Create separate environments for:
- each provider
- each stage
- each risk boundary

### Minimum set
- `aws-dev-preview`
- `aws-dev-deploy`
- `aws-prod-preview`
- `aws-prod-deploy`
- `azure-dev-preview`
- `azure-dev-deploy`
- `azure-prod-preview`
- `azure-prod-deploy`
- `shared-postdeploy`
- `vmware-internal`

### Rules
- preview environments should not share credentials with deploy environments
- prod environments must require reviewers
- internal-only environments should be bound to self-hosted runners

## 3. Variables and secrets

### Repository variables
- `AWS_REGION`
- `TF_VERSION`
- `AZURE_LOCATION`

### Environment variables
- `AWS_ROLE_ARN`
- `AZURE_CLIENT_ID`
- `AZURE_TENANT_ID`
- `AZURE_SUBSCRIPTION_ID`
- optional `TF_WORKING_DIR`
- optional `BICEP_TEMPLATE`

### Secrets
Use secrets only for values that cannot be replaced by OIDC, workload federation, or runtime retrieval from an approved vault.

## 4. Workflow model

Use:
- reusable workflows for each cloud/provider lane
- thin entry workflows for team use
- manual dispatch for controlled deploy lanes
- pull-request validation for preview lanes

## 5. Branch and promotion model

Recommended:
- `main` is the deployment source for prod
- feature branches and pull requests for changes
- deploy preview from PR or non-prod branch
- deploy prod only from protected branch/tag and protected environment

## 6. Evidence model

Each preview and deploy must publish:
- workflow metadata
- commit metadata
- cloud caller identity or login context
- preview/plan/change-set output
- deployment summary
