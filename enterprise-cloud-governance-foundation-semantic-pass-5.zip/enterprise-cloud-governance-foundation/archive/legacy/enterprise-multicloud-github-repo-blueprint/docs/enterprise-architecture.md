# Enterprise Architecture

## 1. Target-state architecture

Use a **three-layer enterprise delivery model**:

1. **Shared CI/CD control plane**
   - GitHub repository
   - GitHub Actions workflows
   - GitHub Environments
   - artifact and evidence retention

2. **Provider-native infrastructure plane**
   - AWS CloudFormation or Terraform
   - Azure Bicep
   - VMware / Aria API-driven or catalog-driven stages where required

3. **Common configuration and post-provisioning plane**
   - Ansible roles and playbooks
   - optional internal tooling or agent deployment stages

## 2. What belongs in GitHub vs outside GitHub

### GitHub should own
- workflow orchestration
- reusable pipeline logic
- approval gates
- artifact retention
- evidence capture
- versioned infrastructure and automation code
- standards and reference documentation

### Cloud providers and private-cloud tools should own
- actual infrastructure lifecycle execution
- control-plane state
- provider-native validation and deployment logic

## 3. Enterprise design rules

- Use one repository or one tightly governed repository set per platform domain, not ad hoc per-team workflow sprawl.
- Use reusable workflows for cloud-specific deployment patterns.
- Use GitHub Environments as deployment trust boundaries.
- Use OIDC or workload federation wherever supported.
- Keep preview and deploy separated.
- Keep dev, test, and prod separated.
- Keep public-cloud jobs and internal-network jobs separated.
- Use Ansible as the broadest common post-provisioning layer.

## 4. Why this pattern works

This pattern keeps the outer governance model consistent while allowing AWS, Azure, and internal/private-cloud tooling to remain platform-native.
