# Runner and Network Boundary Model

## 1. Preferred default

Use GitHub-hosted runners for:
- linting
- validation
- Terraform preview/apply when no private network access is needed
- CloudFormation preview/deploy
- Azure Bicep validate/what-if/deploy
- artifact and evidence packaging

## 2. Use self-hosted runners only for boundary-specific tasks

Use self-hosted runners for:
- Ansible to private targets
- VMware Aria or vSphere API calls not reachable externally
- internal CMDB, ticketing, or vault integrations that require private network paths

## 3. Runner best practices

- separate runner groups by risk boundary
- isolate prod internal jobs from general shared runners
- use ephemeral runners where practical
- patch and monitor runner hosts
- minimize local credential storage
- use outbound-controlled networking
- restrict which repositories can use which runner groups

## 4. Practical pattern

### Public-cloud lane
GitHub-hosted runner
-> OIDC/federated login
-> preview/deploy
-> upload evidence

### Internal lane
Self-hosted runner
-> internal auth/vault retrieval
-> Ansible or Aria stage
-> upload evidence
