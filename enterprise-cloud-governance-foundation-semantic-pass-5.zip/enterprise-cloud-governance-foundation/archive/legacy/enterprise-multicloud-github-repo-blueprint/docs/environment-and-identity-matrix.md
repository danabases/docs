# Environment and Identity Matrix

| Platform | Environment | Purpose | Identity Model | Runner Type | Approval |
|---|---|---|---|---|---|
| AWS | `aws-dev-preview` | Non-prod preview for CloudFormation/Terraform | AWS IAM OIDC role | GitHub-hosted | Optional |
| AWS | `aws-dev-deploy` | Non-prod deployment | AWS IAM OIDC role | GitHub-hosted | Team lead |
| AWS | `aws-prod-preview` | Prod preview / plan only | AWS IAM OIDC role | GitHub-hosted | Required |
| AWS | `aws-prod-deploy` | Prod deployment | AWS IAM OIDC role | GitHub-hosted | Required, restricted |
| Azure | `azure-dev-preview` | Non-prod Bicep validate / what-if | Entra workload federation | GitHub-hosted | Optional |
| Azure | `azure-dev-deploy` | Non-prod Azure deployment | Entra workload federation | GitHub-hosted | Team lead |
| Azure | `azure-prod-preview` | Prod what-if | Entra workload federation | GitHub-hosted | Required |
| Azure | `azure-prod-deploy` | Prod deployment | Entra workload federation | GitHub-hosted | Required, restricted |
| Shared | `shared-postdeploy` | Common post-provisioning | inventory/vault-driven | Self-hosted or GitHub-hosted depending target reachability | Required if prod |
| VMware | `vmware-internal` | Aria / vSphere internal stage | internal service account or vault-issued auth | Self-hosted internal | Required |

## Notes

- Do not reuse one AWS role across preview and deploy.
- Do not reuse one Azure federated identity across dev and prod without a strong justification.
- Do not run internal VMware stages on public runners if private connectivity is required.
