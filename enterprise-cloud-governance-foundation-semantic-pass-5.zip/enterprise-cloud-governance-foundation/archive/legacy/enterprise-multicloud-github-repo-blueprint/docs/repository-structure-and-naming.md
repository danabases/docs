# Repository Structure and Naming

## 1. Recommended repository name

Use a clear enterprise-scoped name such as:

- `enterprise-multicloud-delivery`
- `platform-delivery-foundation`
- `cloud-platform-automation`
- `enterprise-iac-delivery`

Avoid vague names such as `cloud-scripts`, `automation-misc`, or `infra-test`.

## 2. Recommended top-level structure

```text
.github/
  workflows/
docs/
diagrams/
aws/
  cloudformation/
  terraform/
azure/
  bicep/
ansible/
  inventories/
  playbooks/
  roles/
vmware/
  aria/
  scripts/
scripts/
examples/
```

## 3. Naming convention

Use this general pattern:

`<platform>-<domain>-<environment>-<stage>`

### Examples
- `aws-org-prod-deploy`
- `aws-app-dev-preview`
- `azure-platform-prod-deploy`
- `azure-data-test-preview`
- `shared-postdeploy`
- `vmware-internal-prod`

## 4. File and folder naming

### Workflows
- `aws-cloudformation.yml`
- `aws-terraform.yml`
- `azure-bicep.yml`
- `ansible-postdeploy.yml`
- `deploy-aws-cloudformation.yml`
- `deploy-azure-bicep.yml`

### Cloud paths
- `aws/cloudformation/org-guardrails/`
- `aws/cloudformation/account-baselines/`
- `aws/terraform/platform-network/`
- `azure/bicep/subscription-baselines/`
- `azure/bicep/resource-platform/`

### Ansible paths
- `ansible/playbooks/postdeploy-linux.yml`
- `ansible/playbooks/postdeploy-windows.yml`
- `ansible/roles/security-agent/`

### VMware paths
- `vmware/aria/catalog/`
- `vmware/scripts/aria-api-stage.sh`

## 5. Environment names

Use GitHub Environment names that explicitly encode provider, scope, and stage.

### Recommended pattern
`<platform>-<risk-scope>-<stage>`

### Examples
- `aws-dev-preview`
- `aws-dev-deploy`
- `aws-prod-preview`
- `aws-prod-deploy`
- `azure-dev-preview`
- `azure-dev-deploy`
- `azure-prod-preview`
- `azure-prod-deploy`
- `shared-postdeploy`
- `vmware-internal`

## 6. Identity names

### AWS role naming
Use:
`gha-<repo>-<platform>-<env>-<stage>-role`

Example:
- `gha-enterprise-multicloud-delivery-aws-prod-deploy-role`

### Azure federated app / credential naming
Use:
`gha-<repo>-<platform>-<env>-<stage>`

Example:
- `gha-enterprise-multicloud-delivery-azure-prod-deploy`

### Runner group naming
Use:
- `github-hosted-public`
- `selfhosted-internal-shared`
- `selfhosted-vmware-prod`
- `selfhosted-ansible-prod`
