# Enterprise Multi-Cloud GitHub Repository Blueprint

This package provides an opinionated enterprise repository structure for a multi-cloud delivery platform using GitHub.

It is designed to bring together:
- AWS CloudFormation and Terraform lanes
- Azure Bicep lanes
- shared GitHub approval and promotion controls
- optional Ansible post-provisioning
- optional VMware / Aria extension stages
- enterprise naming, environment, and runner standards
- diagram files suitable for keeping in the repository

## Included artifacts

- `docs/enterprise-architecture.md`
- `docs/repository-structure-and-naming.md`
- `docs/github-setup-and-operating-model.md`
- `docs/environment-and-identity-matrix.md`
- `docs/runner-and-network-boundary-model.md`
- `docs/diagram-source.md`
- `diagrams/multicloud-enterprise-structure.mmd`
- `diagrams/multicloud-enterprise-structure.svg`
- `.github/workflows/` reusable and entry workflows
- sample `aws/`, `azure/`, `ansible/`, and `vmware/` folders

## Design objective

Use one GitHub operating model, keep provider-native deployment engines, and standardize approvals, identities, evidence, and promotion.

## Recommended use

Store this repository as:
- a platform engineering reference repo
- a template repo for new program teams
- a governance baseline for enterprise automation
