# AWS Governance Policy-as-Code Starter Set

This repository is a companion implementation package for an enterprise AWS governance standard. It is intended to serve two purposes:

1. **Human-readable governance documentation** for architecture, security, audit, and platform teams.
2. **Machine-usable source material** for policy-as-code, CI/CD validation, control mapping, and future automation.

This starter set includes:

- Example **Service Control Policies (SCPs)** for coarse-grained organizational guardrails.
- Example **IAM permissions boundaries** for delegated administration in workload accounts.
- A **guardrail registry schema** for storing guardrails as structured data that can be validated, versioned, and mapped to code.
- Example **registry data** and **control mappings**.
- Implementation notes and references.

## Repository Structure

```text
aws-governance-pac-starter/
├── README.md
├── docs/
│   ├── implementation-guide.md
│   ├── policy-design-principles.md
│   └── references.md
├── policies/
│   ├── scp/
│   │   ├── deny-disable-cloudtrail.json
│   │   ├── deny-leaving-organization.json
│   │   ├── deny-unapproved-regions.json
│   │   ├── deny-root-user-actions.json
│   │   └── README.md
│   └── permissions-boundaries/
│       ├── delegated-iam-admin-boundary.json
│       ├── workload-operator-boundary.json
│       └── README.md
├── schemas/
│   ├── guardrail-registry.schema.json
│   └── README.md
└── examples/
    ├── mappings/
    │   ├── guardrail-registry.example.yaml
│   │   └── control-mapping.example.yaml
    └── workload-patterns/
        ├── etl-data-platform-pattern.md
        └── application-team-pattern.md
```

## Design Rules

- **SCPs are coarse-grained guardrails only.** They define the maximum available permissions in member accounts. They do not grant permissions. AWS explicitly documents SCPs as maximum-permission guardrails rather than grant mechanisms. See references in [docs/references.md](docs/references.md).
- **Permissions boundaries cap delegated IAM administration.** The effective permissions of an identity are the intersection of identity-based policies and its permissions boundary, and an explicit deny overrides allows.
- **Workload access remains account-local unless explicitly delegated.** Central teams should not automatically inherit workload runtime or data-plane access.
- **Guardrails should be declarative and reviewable.** Every policy should map to an owner, purpose, scope, exception path, and evidence source.

## Intended Usage

This repository can be used as:

- a baseline for AWS Organizations guardrail design,
- source material for Terraform/CloudFormation/CDK integration,
- input to internal control catalogs,
- a reference package for architecture review boards,
- a seed for GitHub-based policy repositories with pull-request review.

## Implementation Notes

- The policy JSON files are **examples** and require environment-specific tailoring.
- Test SCPs in a dedicated non-production OU before broader deployment. AWS explicitly recommends testing SCP impact before broad attachment.
- These examples intentionally favor clarity over maximum compactness.

## Primary References

See [docs/references.md](docs/references.md).
