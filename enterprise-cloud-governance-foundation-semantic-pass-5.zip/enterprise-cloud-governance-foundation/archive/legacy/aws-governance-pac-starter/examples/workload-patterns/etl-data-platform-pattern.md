# Workload Pattern: ETL / Data Platform Team

## Intended operating model

A data platform team owns a production account used for ingestion, transformation, and delivery workloads.

### What the team has
- IAM roles in its own account for ETL jobs.
- Access to create application-scoped roles such as `app-etl-ingest-role`.
- Access to S3 prefixes, KMS keys, Secrets Manager secrets, and data services required by the ETL workflow.
- Read access to account-relevant CloudTrail events, Config history, and security findings.

### Why they have it
They are accountable for service delivery, job reliability, and runtime security of the platform.

### What they do not have
- Permission to disable CloudTrail or Config.
- Permission to detach SCPs.
- Permission to create unrestricted IAM users or access keys.
- Permission to create roles outside approved namespaces or without the required permissions boundary.

### How the controls work
- An SCP denies disabling audit controls.
- A permissions boundary limits any delegated IAM administration to approved role patterns.
- Resource policies and identity policies then grant the exact data-path permissions needed for the workload.
