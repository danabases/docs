# Workload Pattern: Application Team

## Intended operating model

An application team operates a web service in a production workload account.

### What the team has
- Ability to deploy and manage app infrastructure in its own account.
- Ability to pass only approved application roles to EC2, ECS, or Lambda.
- Read access to operational and security telemetry relevant to its account.

### Why they have it
The team is responsible for uptime, secure deployment, and application lifecycle management.

### What they do not have
- Organization-wide administration.
- Ability to create IAM users or long-lived access keys.
- Ability to alter the enterprise log archive or security tooling configuration.
- Ability to bypass the approved-region guardrail.

### How the controls work
- The permissions boundary allows workload operations but denies IAM and Organizations administration.
- The approved-region SCP prevents accidental or unauthorized use of out-of-policy regions.
- Centralized logging preserves evidence for investigation and compliance.
