# Schemas

The schema in this directory defines a machine-readable registry format for governance guardrails.

Use the schema to:

- validate control metadata in CI,
- keep ownership and exception data complete,
- map policies to evidence and implementation artifacts,
- support future automation or dashboarding.
