# Policy Design Principles

This starter set follows AWS's documented policy evaluation and multi-account governance model.

## 1. Effective permissions are the result of multiple policy planes

AWS evaluates requests across identity-based policies, resource-based policies, SCPs, permissions boundaries, and session policies. Access is allowed only when at least one applicable allow exists and no applicable explicit deny exists. An explicit deny in any applicable policy overrides an allow.

### Implication
A team does not actually "have access" because one role policy says it does. It has access only if all applicable policy layers permit the request.

### Example
An engineer has an IAM role allowing `s3:GetObject` on a bucket prefix. If the account's SCP denies the operation, or if the bucket policy allows only requests through a specific VPC endpoint, the request fails.

## 2. SCPs are organizational guardrails, not grant mechanisms

SCPs define the maximum available permissions in member accounts within an AWS Organization. They do not grant any permissions by themselves.

### Implication
An SCP should be used to block classes of actions such as leaving the organization, disabling audit trails, or using unapproved regions. Fine-grained workload access belongs in IAM and resource policies.

## 3. Permissions boundaries are mandatory when IAM administration is delegated

AWS permissions boundaries allow an organization to delegate role and policy management while capping the maximum permissions the delegated administrator can create or assign.

### Implication
If workload teams or platform teams can create roles in an account, those roles should be constrained by a boundary policy. Without a boundary, delegated IAM administration can become privilege escalation.

## 4. Accounts are the primary isolation boundary

AWS treats accounts as a strong administrative and billing boundary. Production, non-production, sensitive, and shared-service workloads should usually be separated by account.

### Implication
Do not use SCPs or complex IAM structures to simulate isolation that should be provided by account separation.

## 5. Evidence and explainability are design requirements

Every guardrail should map to observable evidence such as CloudTrail events, AWS Config state, or security findings. Affected owners should be able to determine what blocked a request and why.

### Implication
No guardrail should exist only as an undocumented central control known to a small inner circle.
