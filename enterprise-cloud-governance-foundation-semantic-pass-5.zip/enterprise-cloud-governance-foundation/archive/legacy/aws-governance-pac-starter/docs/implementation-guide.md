# Implementation Guide

This document explains how to use the companion policy-as-code artifacts in this repository.

## 1. Recommended deployment sequence

1. Define the AWS Organization OU structure.
2. Populate the guardrail registry from `examples/mappings/guardrail-registry.example.yaml`.
3. Review each guardrail's owner, purpose, scope, exception process, and evidence requirements.
4. Deploy permissions boundaries for delegated IAM administrators in target accounts.
5. Test SCPs in a non-production OU.
6. Roll out to narrower production OUs before broader attachment.
7. Monitor CloudTrail and AWS Config for unintended impact.

## 2. What each artifact is for

### `policies/scp/`
Use these policies as **organizational guardrails**. They should be attached at the OU or account level through AWS Organizations.

### `policies/permissions-boundaries/`
Use these as **maximum-permission caps** for delegated IAM administrators or platform operators in workload accounts.

### `schemas/guardrail-registry.schema.json`
Use this JSON Schema to validate a machine-readable inventory of all governance guardrails.

### `examples/mappings/*.yaml`
Use these examples to map governance controls to concrete policies, owners, evidence sources, and exception paths.

## 3. Real-world operating model

### Central governance team
**Has:** ability to create and attach SCPs, manage OU structure, and define account baselines.

**Why:** enterprise guardrails must be consistent across accounts and environments.

**Does not have by default:** permission to read workload secrets, query application data, or administer every application service.

### Security tooling team
**Has:** access to centralized logs, detections, and findings. May manage organization-level security services where delegated administration is used.

**Why:** they need enterprise-wide visibility to detect and investigate abuse or control failures.

**Does not have by default:** routine authority to change workload application configurations outside incident-response workflows.

### Workload owner / application team
**Has:** account-local operational control, including service configuration, app roles, pipelines, and account-relevant logs.

**Why:** they are accountable for the workload's service delivery and runtime security.

**Does not have:** ability to detach SCPs, disable mandatory enterprise logging, or exceed the permissions boundary for delegated IAM administration.

## 4. Recommended CI/CD validations

- Validate SCP JSON syntax before merge.
- Validate guardrail registry files against `schemas/guardrail-registry.schema.json`.
- Require pull-request approval from both the control owner and an independent reviewer for high-impact policies.
- Run policy simulation or static checks where available.
- Enforce metadata completeness: owner, purpose, scope, exception process, review date.

## 5. References

See [references.md](references.md).
