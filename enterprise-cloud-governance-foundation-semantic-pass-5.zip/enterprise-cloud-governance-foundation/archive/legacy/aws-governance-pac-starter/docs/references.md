# References

Primary AWS references used by this starter set:

## Policy evaluation and IAM
- AWS IAM policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- Policies and permissions in AWS IAM: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html
- Permissions boundaries for IAM entities: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- Policy evaluation basics within a single account: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic_policy-eval-basics.html
- Cross-account policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic-cross-account.html

## AWS Organizations and SCPs
- Service control policies (SCPs): https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- SCP syntax: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_syntax.html
- SCP examples: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_examples.html
- Managing organization policies with AWS Organizations: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies.html

## Account model and governance architecture
- AWS Well-Architected Security Pillar – account management and separation: https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html
- AWS Security Reference Architecture – Log Archive account: https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/log-archive.html

## Logging and evidence
- Security best practices in AWS CloudTrail: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- Working with CloudTrail log files: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-working-with-log-files.html
- Encryption best practices for AWS CloudTrail: https://docs.aws.amazon.com/prescriptive-guidance/latest/encryption-best-practices/cloudtrail.html
- AWS Config Security Best Practices for CloudTrail conformance pack: https://docs.aws.amazon.com/config/latest/developerguide/security-best-practices-for-CloudTrail.html
