# Permissions Boundary Policies

These policies are example **permissions boundaries** for delegated IAM administration and workload operations.

## Important behavior

- A permissions boundary defines the **maximum permissions** an identity-based policy can grant to a user or role.
- The effective permissions of a principal are the **intersection** of its identity-based policies and its permissions boundary.
- An explicit deny in the permissions boundary overrides identity-based allows.

## Included examples

- `delegated-iam-admin-boundary.json` – for a platform or workload team that needs to create and manage IAM roles and policies, but only within controlled patterns.
- `workload-operator-boundary.json` – for workload operators who need to manage runtime infrastructure but should not gain account-wide IAM or organization control.

## References

- https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
