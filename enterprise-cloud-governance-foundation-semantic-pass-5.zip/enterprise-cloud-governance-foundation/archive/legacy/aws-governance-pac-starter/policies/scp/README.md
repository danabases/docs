# SCP Policies

These policies are example **Service Control Policies (SCPs)** intended for attachment through AWS Organizations.

## Important behavior

- SCPs define the **maximum available permissions** for principals in member accounts.
- SCPs **do not grant permissions**.
- An explicit deny in an SCP overrides an allow elsewhere.
- Test SCPs in a non-production OU before broad rollout.

## Included examples

- `deny-disable-cloudtrail.json` – blocks common attempts to weaken or disable audit logging.
- `deny-leaving-organization.json` – prevents member accounts from leaving the organization.
- `deny-unapproved-regions.json` – restricts use of services outside an approved region list.
- `deny-root-user-actions.json` – constrains broad usage of the account root principal for selected actions.

## References

- https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_examples.html
- https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_syntax.html
