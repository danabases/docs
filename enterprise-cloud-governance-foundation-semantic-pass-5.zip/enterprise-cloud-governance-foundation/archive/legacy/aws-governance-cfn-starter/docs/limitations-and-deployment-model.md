# Limitations and Deployment Model

## Why this repository separates creation from attachment

The CloudFormation resource `AWS::Organizations::Policy` creates an Organizations policy object. In practice, enterprise teams often also need deterministic policy attachment workflows by OU, account, or root, plus approval and evidence capture. This repository treats those as a separate orchestration concern.

This is intentional because governance controls are not just templates. They are also:

- approval workflows
- target selection logic
- exception handling
- staged rollout logic
- evidence and rollback requirements

## Recommended deployment model

### Option A — Management account pipeline

Use a CI/CD pipeline running in the management account to:

1. deploy or update policy objects with CloudFormation
2. validate registry entries against the schema
3. call Organizations APIs to attach policies to target roots/OUs/accounts
4. record evidence in deployment logs and CloudTrail

### Option B — StackSets for account IAM artifacts

Use StackSets or equivalent account-targeted deployment automation to push permissions-boundary policies and workload-role scaffolding into selected accounts.

### Option C — Registry-driven orchestration

Use the guardrail registry as source-of-truth. A deployment tool resolves:

- which template to deploy
- which parameters to supply
- which OU/account/root targets to attach
- which approvals are required

## Why this aligns with AWS guidance

AWS documents SCPs as maximum-permission guardrails, not grants. AWS also recommends careful testing because deny-based policies can unintentionally block required service behavior if not properly scoped.

**References**
- Service control policies: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- SCP examples and testing guidance: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_examples.html
- Creating policies with AWS Organizations: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_policies_create.html
