# References

## AWS Organizations and SCPs
- AWS::Organizations::Policy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-organizations-policy.html
- AWS Organizations policy management: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies.html
- Service control policies: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- SCP examples: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_examples.html
- General SCP examples: https://docs.aws.amazon.com/en_us/organizations/latest/userguide/orgs_manage_policies_scps_examples_general.html
- Policy creation: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_policies_create.html
- Policy attachment: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_policies_attach.html
- Organizations delegated resource policy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-organizations-resourcepolicy.html

## IAM and policy evaluation
- Policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- Policies and permissions in IAM: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html
- Permissions boundaries: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- Example IAM identity-based policies: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_examples.html

## CloudFormation IAM resources
- AWS::IAM::ManagedPolicy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-iam-managedpolicy.html
- AWS::IAM::Role: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-iam-role.html
- AWS::IAM::Policy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-iam-policy.html
- AWS::IAM::RolePolicy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-iam-rolepolicy.html

## AWS SSO / IAM Identity Center
- AWS::SSO::PermissionSet: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-sso-permissionset.html
- Permission set permissions boundary: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-properties-sso-permissionset-permissionsboundary.html

## Logging and governance
- CloudTrail security best practices: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
- AWS Security Reference Architecture: https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/introduction.html
- Log archive pattern: https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/log-archive.html
- AWS account management and separation: https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html
