# Implementation Guide

## Purpose

This document explains how to use the CloudFormation starter repository to deploy enterprise AWS guardrails while preserving distributed workload ownership and auditable control boundaries.

## Deployment layers

### 1. Organization guardrail layer

Use templates in `templates/org/` from the AWS Organizations management account or a delegated administrator account where supported. AWS documents that `AWS::Organizations::Policy` can create an organization policy and that this operation can be called only from the organization's management account or a member account designated as a delegated administrator.

**References**
- AWS::Organizations::Policy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-organizations-policy.html
- Managing organization policies: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies.html

### 2. Account IAM layer

Use templates in `templates/iam/` inside workload, shared services, or delegated admin accounts to create customer managed policies used as permissions boundaries and reusable managed policy artifacts.

A permissions boundary is a managed policy that sets the maximum permissions an identity-based policy can grant to a user or role. It does not grant permissions by itself.

**References**
- Permissions boundaries: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- AWS::IAM::ManagedPolicy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-iam-managedpolicy.html

### 3. Composition layer

Use templates in `templates/stacks/` for repeatable deployment patterns. These templates are intentionally modular so that organizations can deploy them through StackSets, CI/CD pipelines, or management-account workflows.

## Effective permission model

Any deployment built from this repository must respect AWS policy evaluation logic:

- IAM identity-based policies grant permissions.
- Resource-based policies can grant permissions directly to a principal or trusted account.
- Permissions boundaries cap what identity-based policies can grant.
- Service control policies cap the maximum available permissions in member accounts.
- An explicit deny in any applicable policy overrides an allow.

**References**
- Policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- Policies and permissions in IAM: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html

## Recommended rollout sequence

1. Deploy guardrail registry schema and registry data to source control.
2. Create SCP objects with CloudFormation.
3. Validate SCP content in a non-production OU.
4. Create permissions boundary policies in target accounts.
5. Roll out IAM role templates that explicitly reference those boundary ARNs.
6. Use pipeline logic or delegated administration workflows to attach SCPs to roots, OUs, or accounts.
7. Enable centralized audit logging and verify CloudTrail evidence for all deployments.

**References**
- SCP examples and testing caution: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps_examples.html
- CloudTrail security best practices: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/best-practices-security.html
