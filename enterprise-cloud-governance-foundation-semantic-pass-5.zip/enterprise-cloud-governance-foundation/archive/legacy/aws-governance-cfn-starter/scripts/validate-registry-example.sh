#!/usr/bin/env bash
set -euo pipefail

SCHEMA_PATH="schemas/guardrail-registry.schema.json"
REGISTRY_PATH="examples/mappings/guardrail-registry.example.yaml"

echo "Validate ${REGISTRY_PATH} against ${SCHEMA_PATH} with your preferred JSON Schema + YAML validation tooling."
echo "Example tools: ajv, python jsonschema + ruamel.yaml, or CI-native validation action."
