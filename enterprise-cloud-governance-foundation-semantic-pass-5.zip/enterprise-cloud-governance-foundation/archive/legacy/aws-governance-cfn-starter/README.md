# AWS Governance CloudFormation Starter

This repository is a companion CloudFormation starter set for the AWS governance standard and policy-as-code starter repository. It provides reusable CloudFormation templates, parameter examples, and a machine-readable registry pattern for deploying organization guardrails and account-level IAM controls in a controlled way.

## Design intent

This repository is organized so it can be used in two ways:

1. **Human-readable implementation source** for platform, security, audit, and workload teams.
2. **Machine-consumable source** for pipelines that render, validate, deploy, or attach governance controls.

## What is included

- `templates/org/` — organization-level CloudFormation templates for AWS Organizations policies
- `templates/iam/` — account-level IAM managed policies and permissions-boundary patterns
- `templates/stacks/` — composition templates for repeatable deployment patterns
- `schemas/` — machine-readable schema for a guardrail registry
- `examples/` — sample parameter files and registry mappings
- `docs/` — implementation and deployment guidance
- `scripts/` — helper script examples for packaging/validation workflows

## Important scope note

CloudFormation can **create AWS Organizations policies**, but CloudFormation does not currently provide a native resource to attach an Organizations policy to a target in the same direct way many teams expect. This starter set therefore separates:

- **policy creation** in CloudFormation
- **policy attachment/orchestration** through registry-driven external deployment logic, StackSets, or pipeline automation

See `docs/limitations-and-deployment-model.md` for the deployment model and rationale.

## References

- AWS::Organizations::Policy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-organizations-policy.html
- Service control policies: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
- Policy evaluation logic: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html
- Permissions boundaries: https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_boundaries.html
- AWS::IAM::ManagedPolicy: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-iam-managedpolicy.html
- AWS::IAM::Role: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-iam-role.html
