# Guardrail Exception Request Template

- Request ID:
- Guardrail ID:
- Requestor:
- Affected account(s) / OU(s):
- Business justification:
- Requested duration:
- Risk summary:
- Compensating controls:
- Approval authority:
- Expiration / review date:
