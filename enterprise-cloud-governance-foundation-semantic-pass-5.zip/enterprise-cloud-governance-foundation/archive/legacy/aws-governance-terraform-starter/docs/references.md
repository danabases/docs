# References

- Terraform Registry: `aws_organizations_policy`
- Terraform Registry: `aws_organizations_policy_attachment`
- Terraform Registry: `aws_iam_policy`
- Terraform Registry: `aws_iam_role`
- Terraform Registry: `aws_iam_role_policy_attachment`
- Terraform Registry: `aws_iam_policy_document`
- AWS Organizations SCP documentation
- AWS IAM permissions boundaries documentation
- AWS IAM policy evaluation logic
