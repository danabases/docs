# Implementation Guide

## Design intent

This repository separates:
1. **policy documents** from
2. **Terraform modules** from
3. **environment/root-module composition** from
4. **registry metadata**

That split supports change control, targeted testing, and future automation.

## Recommended workflow

1. Author or update the policy JSON in `policies/`.
2. Register the guardrail in the YAML registry.
3. Deploy the relevant Terraform root module into a safe scope.
4. Validate CloudTrail, account impact, and exception handling.
5. Promote to broader OU/account scope only after evidence review.

## Scope model

- Use `environments/org-policies` from an account and principal authorized to manage AWS Organizations policies.
- Use `environments/account-iam-baseline` inside workload or shared accounts for IAM managed policies and example roles.

## Why separate SCPs from account IAM

SCPs are maximum-permission guardrails at the organization plane. Permissions boundaries and IAM roles are account-local IAM controls. Keeping them in separate root modules reduces blast radius and supports cleaner approvals.

## Recommended state handling

Use a remote backend with locking, versioning, and restricted access. Do not manage high-impact organization policies from local state.

## Testing guidance

- Test deny-based SCPs in a sandbox OU first.
- Validate service behavior for break-glass, logging, security tooling, and CI/CD roles.
- Validate that account owners can still determine the source of denials and policy changes.
