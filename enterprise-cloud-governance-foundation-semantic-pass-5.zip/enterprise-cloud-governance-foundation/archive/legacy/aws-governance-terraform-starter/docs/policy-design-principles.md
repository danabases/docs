# Policy Design Principles

## SCPs

Use SCPs for coarse-grained governance only:
- region restrictions
- prevent leaving the organization
- prevent disabling centralized audit controls
- root-user restrictions

Do not try to implement full application authorization inside SCPs.

## Permissions boundaries

Use permissions boundaries when delegating IAM creation or modification rights. A boundary caps the maximum permissions that a delegated principal can assign to roles or users it creates.

## Terraform design

- Prefer `aws_iam_policy_document` or `jsonencode()` for generated JSON.
- Keep policy documents reviewable in source control.
- Avoid monolithic root modules that combine org-plane and workload-plane changes.
- Attach managed policies to roles with `aws_iam_role_policy_attachment` rather than the exclusive account-wide attachment resource.

## Review gates

Every high-impact policy change should have:
- owner
- purpose
- approval record
- target scope
- rollback plan
- evidence of validation
