# AWS Governance Terraform Starter

Terraform companion package for the AWS governance markdown and CloudFormation starter sets.

## Contents

- `modules/scp` - creates AWS Organizations policy objects and optional attachments
- `modules/permissions-boundary` - creates customer-managed IAM policies for permissions boundaries
- `modules/role-with-boundary` - sample IAM role module enforcing a permissions boundary
- `environments/org-policies` - starter root module for SCP deployment
- `environments/account-iam-baseline` - starter root module for account-level IAM baseline deployment
- `policies/scp` - starter SCP JSON policy documents
- `policies/permissions-boundaries` - starter permissions-boundary JSON policy documents
- `schemas/guardrail-registry.schema.json` - machine-readable schema for a guardrail registry
- `examples/guardrails/guardrail-registry.example.yaml` - sample registry entries
- `docs` - implementation and deployment guidance

## Notes

This package is intentionally conservative. It is designed as a starter set:
- creates SCP objects and can attach them to roots/OUs/accounts
- creates customer-managed policies intended for use as permissions boundaries
- demonstrates Terraform structure for registry-driven governance deployment

Test deny-based controls in a non-production OU or equivalent safe scope before wider rollout.
