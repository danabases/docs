terraform {
  required_version = ">= 1.6.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.0"
    }
  }
}

provider "aws" {
  region = var.region
}

module "boundaries" {
  for_each    = var.permissions_boundaries
  source      = "../../modules/permissions-boundary"
  name        = each.value.name
  description = try(each.value.description, null)
  path        = try(each.value.path, "/")
  policy_json = file(each.value.policy_file)
  tags        = merge(var.default_tags, try(each.value.tags, {}))
}

module "roles" {
  for_each                 = var.roles
  source                   = "../../modules/role-with-boundary"
  name                     = each.value.name
  description              = try(each.value.description, null)
  assume_role_policy_json  = each.value.assume_role_policy_json
  permissions_boundary_arn = module.boundaries[each.value.permissions_boundary_key].arn
  managed_policy_arns      = try(each.value.managed_policy_arns, [])
  tags                     = merge(var.default_tags, try(each.value.tags, {}))
}
