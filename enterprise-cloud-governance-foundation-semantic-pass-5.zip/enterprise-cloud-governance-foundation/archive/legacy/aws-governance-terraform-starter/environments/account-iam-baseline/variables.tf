variable "region" {
  type    = string
  default = "us-east-1"
}

variable "default_tags" {
  type    = map(string)
  default = {}
}

variable "permissions_boundaries" {
  type = map(object({
    name        = string
    description = optional(string)
    path        = optional(string)
    policy_file = string
    tags        = optional(map(string))
  }))
}

variable "roles" {
  type = map(object({
    name                     = string
    description              = optional(string)
    permissions_boundary_key = string
    assume_role_policy_json  = string
    managed_policy_arns      = optional(set(string))
    tags                     = optional(map(string))
  }))
  default = {}
}
