variable "region" {
  type    = string
  default = "us-east-1"
}

variable "default_tags" {
  type    = map(string)
  default = {}
}

variable "policies" {
  type = map(object({
    name         = string
    description  = optional(string)
    content_file = string
    target_ids   = optional(set(string))
    tags         = optional(map(string))
  }))
}
