terraform {
  required_version = ">= 1.6.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.0"
    }
  }
}

provider "aws" {
  region = var.region
}

module "scp" {
  for_each    = var.policies
  source      = "../../modules/scp"
  name        = each.value.name
  description = try(each.value.description, null)
  content     = file(each.value.content_file)
  target_ids  = try(each.value.target_ids, [])
  tags        = merge(var.default_tags, try(each.value.tags, {}))
}
