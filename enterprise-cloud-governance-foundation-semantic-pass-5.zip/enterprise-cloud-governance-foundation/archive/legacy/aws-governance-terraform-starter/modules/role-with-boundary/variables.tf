variable "name" { type = string }
variable "description" { type = string, default = null }
variable "assume_role_policy_json" { type = string }
variable "permissions_boundary_arn" { type = string }
variable "managed_policy_arns" { type = set(string), default = [] }
variable "tags" { type = map(string), default = {} }
