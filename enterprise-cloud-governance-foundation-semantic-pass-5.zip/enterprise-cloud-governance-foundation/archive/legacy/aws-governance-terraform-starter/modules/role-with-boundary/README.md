# role-with-boundary module

Creates an IAM role and enforces a permissions boundary via the role resource.
