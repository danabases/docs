# permissions-boundary module

Creates a customer-managed IAM policy intended for use as a permissions boundary.
