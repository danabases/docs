output "policy_id" {
  value = aws_organizations_policy.this.id
}

output "policy_arn" {
  value = aws_organizations_policy.this.arn
}
