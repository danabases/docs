# scp module

Creates an AWS Organizations SCP object and optionally attaches it to target roots, OUs, or accounts.
