variable "name" {
  type = string
}

variable "description" {
  type    = string
  default = null
}

variable "content" {
  type = string
}

variable "target_ids" {
  type        = set(string)
  default     = []
  description = "Organizations root, OU, or account IDs to attach the policy to."
}

variable "tags" {
  type    = map(string)
  default = {}
}
