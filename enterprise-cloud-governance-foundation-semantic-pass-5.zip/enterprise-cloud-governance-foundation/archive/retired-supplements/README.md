# Retired Supplements

These files were retained only for traceability during consolidation. Their substantive content has now been merged into the canonical standards, controls, and RACI artifacts in the active repository tree.

Do not update files in this directory.

## Architecture and repository supplements retired in the second semantic pass

- environment-model-supplement.md
- runner-and-network-boundary-model-supplement.md
- runner-strategy-supplement.md
- environment-and-identity-matrix.md
- account-and-control-plane-model.md
- architecture-and-best-practices-supplement.md
- enterprise-architecture-supplement.md
- repository-structure-and-naming-supplement.md
- multi-cloud-and-vmware-compatibility.md
