# Exception Request

- Request ID:
- Requestor:
- Standard / Control:
- Scope:
- Business Rationale:
- Compensating Controls:
- Start Date:
- End Date:
- Reviewer(s):
- Approver:
- Decision:
