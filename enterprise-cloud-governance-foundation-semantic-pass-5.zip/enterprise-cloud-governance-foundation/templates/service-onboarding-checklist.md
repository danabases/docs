# Service Onboarding Checklist

- [ ] Business and technical owners assigned
- [ ] Environment and data classification identified
- [ ] Landing zone / account / subscription requested
- [ ] Required tags and naming confirmed
- [ ] Logging and evidence destinations confirmed
- [ ] Identity model approved
- [ ] Guardrail profile selected
- [ ] Support and escalation path documented
