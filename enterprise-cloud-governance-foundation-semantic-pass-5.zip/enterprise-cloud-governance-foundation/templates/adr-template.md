# Architecture Decision Record

- ADR ID:
- Title:
- Status:
- Date:
- Context:
- Decision:
- Consequences:
- Related Standards:
- Related Controls:
- Related Exceptions:
