# AWS automation execution model

This directory no longer contains active GitHub Actions workflow entrypoints.

## Canonical execution surface

Use the repository-root workflows under `.github/workflows/` for all active execution:

- `deploy-aws-cloudformation.yml`
- `deploy-aws-terraform.yml`
- `cloudformation-validate.yml`
- `terraform-validate.yml`
- reusable workflow implementations under `.github/workflows/reusable/`

## Why the platform-local workflows were retired

The former files in `platforms/aws/automation/workflows/` duplicated the active execution paths, used pre-consolidation relative paths such as `templates/...`, `environments/...`, and `scripts/...`, and created two competing workflow surfaces for the same AWS deployment operations.

That duplication increased drift risk and made it unclear which workflows were authoritative.

## Archived workflow set

The retired platform-local workflows are preserved for traceability under:

`archive/retired-workflows/platforms-aws-automation/`

They should be treated as historical reference only and must not be used for active deployment.
