# Operating Model

## Model Summary

The enterprise operating model should be **centralized in guardrail authority and distributed in service ownership and operational visibility**.

## Control Planes

1. Governance control plane
2. Shared platform control plane
3. Workload control plane
4. Data platform control plane

## Rules of Engagement

- Standards live here; implementation repos inherit or reference them.
- Exceptions are approved here and consumed elsewhere.
- High-level governance changes must be made by pull request.
- No top-level governance control should be changed without an evidence trail.
- Workload teams must retain visibility into controls that affect them.
