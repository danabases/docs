# Exception and Risk Management

## Exception Model

Exceptions are formal temporary deviations from an approved standard or control requirement.

## Risk Model

Where exceptions introduce risk, a linked risk record should be created with impact, likelihood, owner, and target remediation date.
