# Repository Structure and Naming

## Canonical Repository Name

Use a single enterprise-scoped repository name:

- `enterprise-cloud-governance-foundation`

Avoid vague names such as `cloud-scripts`, `automation-misc`, or `infra-test`.

## Optional Supporting Repositories

Only split supporting repositories when a separate lifecycle is required, such as:

- `enterprise-platform-runner-images`
- `enterprise-policy-test-harness`
- `enterprise-shared-observability-patterns`

## File Naming

Use lower-case, hyphen-separated file names.

## Top-Level Structure

```text
.github/
  workflows/
architecture/
controls/
docs/
examples/
platforms/
raci/
schemas/
standards/
templates/
tooling/
```

## Structural Rules

- standards belong in `standards/`
- architecture narratives belong in `architecture/`
- control metadata belongs in `controls/`
- machine-validated YAML or JSON must have an associated schema in `schemas/` when feasible
- templates belong in `templates/`
- platform-specific deployable assets belong in `platforms/<provider>/`
- reusable CI/CD workflows belong in `.github/workflows/reusable/`
- examples must not become the canonical source of truth for deployable assets
- diagrams belong in `architecture/diagrams/`
- internal utilities and packaging scripts belong in `tooling/`
- retired or superseded source material belongs under `archive/`

## Naming Guidance

- prefer enterprise, platform, control, or provider terms that match the actual ownership boundary
- keep repository, directory, and file names stable once referenced by workflows
- use explicit provider names such as `aws`, `azure`, and `vmware` instead of vague shared labels
- distinguish deployable assets from scaffolds by naming examples as `*-example.*` or `*-sample.*`
