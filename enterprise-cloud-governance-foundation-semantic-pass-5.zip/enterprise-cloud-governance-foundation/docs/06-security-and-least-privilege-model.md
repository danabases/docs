# Security and Least-Privilege Model

## Required Characteristics

- least privilege for human and workload identities
- no persistent broad admin roles for routine work
- time-bound elevation for privileged functions
- centralized guardrails with distributed visibility
- environment separation for dev, test, prod
- role separation between governance, identity, platform, network, workloads, and data platform
- evidence retention for control-plane changes

## Reciprocal Visibility Requirement

Any team materially affected by a top-level governance action must be able to inspect the resulting policy, assignment, or approved exception through documented governance channels.
