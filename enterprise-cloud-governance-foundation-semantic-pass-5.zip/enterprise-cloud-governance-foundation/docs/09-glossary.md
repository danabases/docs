# Glossary

| Term | Meaning |
|---|---|
| Guardrail | Preventive or detective enterprise control applied to a platform or workload scope |
| Landing Zone | Standardized cloud foundation model for accounts, subscriptions, networking, identity, and policy |
| Reciprocal Visibility | The principle that governance operators and governed teams must have transparent, reviewable control actions |
| Exception | Approved deviation from a control or standard |
| ADR | Architecture decision record |
