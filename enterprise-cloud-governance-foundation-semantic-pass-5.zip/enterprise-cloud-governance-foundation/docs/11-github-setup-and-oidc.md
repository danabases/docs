# GitHub Setup and OIDC

This document defines the recommended GitHub Actions trust and environment model for this repository.

## Objective

Use short-lived federated credentials for deployment workflows instead of long-lived static secrets.

## AWS OIDC Pattern

1. Create an IAM OIDC provider for `https://token.actions.githubusercontent.com`.
2. Create one or more IAM roles trusted by that provider.
3. Constrain trust conditions to the specific repository, branch, tag, or GitHub Environment subject.
4. Attach least-privilege policies to each role.
5. Use separate roles for validation, preview, and deployment where practical.

Reference example:

- `examples/aws/oidc-trust-policy-example.json`

## Azure Federated Credential Pattern

1. Register an application or workload identity for GitHub Actions.
2. Create federated credentials bound to the repository and environment subject.
3. Scope permissions to the minimum subscription, management group, or resource group required.
4. Separate preview identities from deployment identities when approval boundaries differ.

Reference examples:

- `examples/azure/federated-credential-example.md`
- `examples/azure/federated-credential-notes.md`

## GitHub Environment Model

Use GitHub Environments to separate preview and deployment gates, such as:

- `aws-dev-preview`
- `aws-prod-deploy`
- `azure-dev-preview`
- `azure-prod-deploy`
- `shared-postdeploy`

Each environment should define only the variables and approvals required for its scope.

## Repository Variables

Typical variables include:

- `AWS_REGION`
- `AWS_ROLE_ARN`
- `AZURE_CLIENT_ID`
- `AZURE_TENANT_ID`
- `AZURE_SUBSCRIPTION_ID`
- `AZURE_LOCATION`
- `TF_VERSION`

See `examples/github/environment-secrets-and-vars.md`.

## Hardening Guidance

- restrict reusable workflow invocation to approved branches and environments
- use separate identities for AWS CloudFormation, AWS Terraform, and Azure Bicep when blast radius differs
- require approvals for production deployment environments
- prefer organization-managed runner pools only when network isolation or private connectivity is required
- capture evidence artifacts for validation, preview, and deployment runs

## References

See [references.md](references.md).
