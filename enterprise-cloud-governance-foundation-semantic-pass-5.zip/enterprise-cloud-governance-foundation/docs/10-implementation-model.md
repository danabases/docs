# Implementation Model

This document defines how the consolidated repository should be used operationally.

## Layering Model

Keep the repository separated into four layers:

1. **Governance layer** — principles, standards, and operating model in `docs/` and `standards/`.
2. **Control-definition layer** — control catalog, mappings, registry, and schemas in `controls/` and `schemas/`.
3. **Implementation layer** — provider-specific deployable artifacts in `platforms/`.
4. **Automation layer** — validation, deployment orchestration, and evidence collection in `.github/workflows/` and `tooling/`.

## Recommended Deployment Sequence

1. Establish the enterprise operating model and RACI.
2. Approve the control catalog and guardrail registry.
3. Validate machine-readable control metadata against the published schemas.
4. Deploy AWS account-level boundaries and baselines in non-production.
5. Test organization-level SCPs in a controlled OU before broader rollout.
6. Promote validated Terraform, CloudFormation, and Bicep assets through environment-gated workflows.
7. Capture deployment evidence and retain change records for auditability.

## Canonical Implementation Paths

### AWS policy definitions

- `platforms/aws/policies/scp/`
- `platforms/aws/policies/permissions-boundaries/`

### AWS Terraform

- `platforms/aws/terraform/environments/account-iam-baseline/`
- `platforms/aws/terraform/environments/org-policies/`
- `platforms/aws/terraform/modules/`

### AWS CloudFormation

- `platforms/aws/cloudformation/templates/stacks/account-iam-baseline.yaml`
- `platforms/aws/cloudformation/templates/stacks/org-policy-catalog.yaml`
- `platforms/aws/cloudformation/templates/iam/`
- `platforms/aws/cloudformation/templates/org/`

### Azure Bicep

- `platforms/azure/bicep/main.bicep`

### Workflow orchestration

- `.github/workflows/deploy-aws-cloudformation.yml`
- `.github/workflows/deploy-aws-terraform.yml`
- `.github/workflows/deploy-azure-bicep.yml`
- `.github/workflows/multicloud-orchestrator.yml`

## Operational Responsibilities

### Central governance team

Has authority to define enterprise guardrails, approve exceptions, and own the machine-readable control model.

Does not automatically receive blanket access to workload secrets, business data, or application operations.

### Security tooling or SecOps

Has enterprise visibility into centralized evidence, detections, and control outcomes.

Does not automatically receive routine workload administration rights outside approved incident procedures.

### Workload owners

Have responsibility for account-local or subscription-local service delivery inside approved guardrails.

Do not have authority to bypass enterprise SCPs, mandatory logging, or delegated administrator boundaries.

## Pipeline and Platform Model

Use one orchestration plane for approvals, promotion, artifacts, and evidence, while keeping provider-native deployment engines underneath it:

- AWS: CloudFormation or Terraform
- Azure: Bicep
- VMware or internal platforms: API- or playbook-driven stages
- Common post-provisioning: Ansible first, other tools only where clearly justified

Do not treat VMware-specific tooling as the universal abstraction for AWS and Azure.

## CI/CD Validation Requirements

At a minimum, pull requests should:

- validate the guardrail registry against `schemas/guardrail-registry.schema.json`
- validate internal markdown links
- run `terraform fmt -check` and `terraform validate`
- lint CloudFormation templates with `cfn-lint`
- compile Bicep templates
- require independent review for high-impact policy changes

## Examples and Non-Canonical Assets

Use `examples/` for samples, parameter scaffolds, onboarding aids, and walkthroughs.

Do not treat files under `examples/` as the source of truth when a canonical implementation already exists under `platforms/`, `controls/`, or `schemas/`.

## References

See [references.md](references.md).
