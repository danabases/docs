# References

## AWS

- AWS Organizations SCPs
- AWS IAM permissions boundaries
- AWS IAM policy evaluation logic
- AWS CloudTrail security best practices
- AWS Prescriptive Guidance: Security Reference Architecture

## GitHub Actions and OIDC

- GitHub Actions OIDC for AWS
- GitHub Actions reusable workflows
- GitHub Environments and deployment protection rules

## Azure

- Azure Bicep deployment commands
- Azure federated credentials for workload identities

## Repository-specific references

- `architecture/enterprise-multicloud-reference-architecture.md`
- `docs/05-reference-architecture.md`
- `docs/06-security-and-least-privilege-model.md`
- `standards/policy-as-code-standard.md`
- `controls/control-implementation-matrix.md`
