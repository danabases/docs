# Reference Architecture

The recommended enterprise pattern is a three-layer delivery model:

1. **Shared CI/CD control plane**
   - GitHub repository
   - GitHub Actions workflows
   - GitHub Environments
   - artifact and evidence retention

2. **Provider-native infrastructure plane**
   - AWS CloudFormation or Terraform
   - Azure Bicep
   - VMware or Aria API-driven stages where required

3. **Common configuration and post-provisioning plane**
   - Ansible roles and playbooks
   - optional internal tooling or agent deployment stages

## Architecture Rules

- keep the outer governance model consistent while allowing AWS, Azure, and internal tooling to remain platform-native
- use GitHub Environments as deployment trust boundaries
- keep preview and deploy separated
- keep dev, test, and prod separated
- keep public-cloud jobs and internal-network jobs separated
- use OIDC or workload federation wherever supported
- use Ansible as the broadest common post-provisioning layer

## Why GitHub Is the Outer Control Plane

GitHub should own:

- workflow orchestration
- reusable pipeline logic
- approval gates
- artifact retention
- evidence capture
- versioned infrastructure and automation code
- standards and reference documentation

Providers and private-cloud tools should own actual infrastructure execution and provider-native deployment state.

## Platform Compatibility Model

Use one orchestration system to govern promotion, approvals, federated authentication, artifact handling, and evidence collection across providers.

This layer can call:

- AWS CloudFormation for AWS
- Terraform for AWS where module-driven multi-account deployment is preferred
- Azure Bicep for Azure
- VMware Aria or vSphere automation for internal virtualization workflows
- Ansible for post-provisioning and configuration tasks

Do not force one cloud’s template model onto another.

## Runner Strategy

Use GitHub-hosted runners for public-cloud validation and standard CLI tasks unless private network access is required.

Use self-hosted runners only when:

- private network access is needed
- on-prem APIs are reachable only internally
- enterprise network controls require execution inside the boundary

## Evidence Model

Every preview and deployment workflow should capture:

- workflow metadata
- commit SHA and ref
- environment name
- caller identity
- preview or plan output
- deployment output

See `architecture/enterprise-multicloud-reference-architecture.md` for the primary narrative and `architecture/diagrams/` for visual artifacts.
