# Workflow Patterns

These files are reference patterns. Copy or adapt them into implementation repositories. They exist here so governance expectations for deployment pipelines remain documented and standardized.
