# GitHub Actions Patterns

## Expectations

- validate markdown and YAML on pull request
- validate registry YAML against schema
- separate preview/plan from deploy/apply
- protect production environments with approval gates
- use OIDC or federation, not static secrets, where supported
- publish evidence artifacts for deployments and governance changes
