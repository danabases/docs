# Reusable workflow taxonomy

This directory contains the canonical reusable workflows consumed by the top-level entrypoint workflows under `.github/workflows/`.

## Canonical reusable workflows
- `aws-cloudformation.yml` - reusable AWS CloudFormation preview/deploy implementation
- `aws-terraform.yml` - reusable AWS Terraform preview/deploy implementation
- `azure-bicep.yml` - reusable Azure Bicep preview/deploy implementation
- `ansible-postdeploy.yml` - reusable Ansible post-deployment implementation

## Naming rule
Use `<provider-or-domain>-<engine-or-purpose>.yml` for reusable workflows. Avoid parallel generic wrappers such as `reusable-aws-deploy.yml` when a provider-and-engine specific workflow already exists.

## Lifecycle rule
Top-level workflows are entrypoints. Files in this directory are implementation units. Redundant wrapper workflows are retired under `archive/retired-workflows/` for traceability and must not be referenced by active workflows.
